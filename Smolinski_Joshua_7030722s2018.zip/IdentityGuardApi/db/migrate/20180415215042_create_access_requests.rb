class CreateAccessRequests < ActiveRecord::Migration
  def change
    create_table :access_requests do |t|
      t.string :guid
      t.string :client_id
      t.string :user_id
      t.string :datum_key
      t.string :status

      t.timestamps null: false
    end
  end
end
