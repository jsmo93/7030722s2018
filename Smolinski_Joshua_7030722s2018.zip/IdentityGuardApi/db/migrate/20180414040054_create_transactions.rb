class CreateTransactions < ActiveRecord::Migration
  def change
    create_table :transactions do |t|
      t.string :guid
      t.string :client_id
      t.string :user_id
      t.string :datum_id

      t.timestamps null: false
    end
  end
end
