class CreateData < ActiveRecord::Migration
  def change
    create_table :data do |t|
      t.string :guid
      t.string :user_id
      t.string :key
      t.text :value
      t.text :iv

      t.timestamps null: false
    end
  end
end
