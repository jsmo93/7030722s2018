class CreateClients < ActiveRecord::Migration
  def change
    create_table :clients do |t|
      t.string :guid
      t.string :name
      t.text :public_key

      t.timestamps null: false
    end
  end
end
