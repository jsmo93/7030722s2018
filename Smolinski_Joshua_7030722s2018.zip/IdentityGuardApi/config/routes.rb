Rails.application.routes.draw do
  scope '/' do
    get '/', to: redirect('/api/v1')
    scope '/api' do
      get '/', to: redirect('/v1')
      scope '/v1' do
        get '/' => 'api_v_one#index'
        resources :users, :only => [:create]
        resources :data, :only => [:create]
        resources :sequence_numbers, :only => [:create]
        resources :access_requests, :only => [:create]
        resources :transactions, :only => [:create]
        resources :alerts, :only => [:create]
      end
    end
  end
end
