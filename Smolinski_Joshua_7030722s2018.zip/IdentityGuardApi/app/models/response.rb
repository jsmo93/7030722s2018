require 'openssl'
require 'base64'

class Response
  attr_reader :response_hash
  def initialize(response, recipient, is_seq)
    @response_hash = nil

    # Generate a new sequence number for the client
    client = Client.find_by_guid(recipient)
    unless is_seq
      seq_guid = SecureRandom.uuid
      sequence_number = SequenceNumber.create(guid: seq_guid, client_id: client.guid, status: Const::STATUS_PENDING)

      # Add the new sequence number to the response
      object = {}
      object[Const::KEY_GUID] = sequence_number.guid
      response[Const::KEY_SEQUENCE_NUMBER] = object
    end

    # Encrypt the response hash, encrypt the key, and generate the signature
    symmetric_hash = encrypt_response(response)
    key = encrypt_key(symmetric_hash[Const::KEY_KEY], client.public_key)
    signature = sign_key(key)

    # Create the response
    response = {}
    object = {}
    object[Const::KEY_KEY] = key
    object[Const::KEY_SECRET] = symmetric_hash[Const::KEY_SECRET]
    object[Const::KEY_ENCRYPTED_RESPONSE] = symmetric_hash[Const::KEY_ENCRYPTED_RESPONSE]
    object[Const::KEY_SIGNATURE] = signature
    response[Const::KEY_RESPONSE] = object

    @response_hash = response
  end

  # ########################################
  # Response helper methods
  # ########################################
  def encrypt_key(symmetric_key, client_key)
    public_key = OpenSSL::PKey::RSA.new(client_key, Secrets::DATUM_VALUE_ENCRYPTION_KEY)
    decoded_key = public_key.public_encrypt(symmetric_key)
    Base64.encode64(decoded_key)
  end

  def encrypt_response(response)
    cipher = OpenSSL::Cipher::AES.new(Const::ENCRYPTION_LENGTH, :CBC)
    cipher.encrypt

    key = SecureRandom.hex(16)
    iv = SecureRandom.hex(8)

    cipher.key = key
    cipher.iv = iv

    encrypted = cipher.update(response.to_s) + cipher.final
    encrypted_hash = {}
    encrypted_hash[Const::KEY_ENCRYPTED_RESPONSE] = Base64.encode64(encrypted)
    encrypted_hash[Const::KEY_KEY] = Base64.encode64(key)
    encrypted_hash[Const::KEY_SECRET] = Base64.encode64(iv)
    encrypted_hash
  end

  def sign_key(encoded_key)
    private_key = OpenSSL::PKey::RSA.new(Secrets::SERVER_KEY, Secrets::DATUM_VALUE_ENCRYPTION_KEY)
    signature = private_key.private_encrypt(encoded_key[0...128])
    Base64.encode64(signature)
  end
end