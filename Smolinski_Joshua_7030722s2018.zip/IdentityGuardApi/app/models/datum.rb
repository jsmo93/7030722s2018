class Datum < ActiveRecord::Base
end
