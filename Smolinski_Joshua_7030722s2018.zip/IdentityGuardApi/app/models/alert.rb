class Alert < ActiveRecord::Base
end
