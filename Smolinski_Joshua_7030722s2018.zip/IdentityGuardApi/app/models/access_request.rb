class AccessRequest < ActiveRecord::Base
end
