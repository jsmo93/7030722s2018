class Const
  SEQUENCE_NUMBER_EXPIRATION = 15

  KEY_KEY = "key"
  KEY_SECRET = "secret"
  KEY_CLIENT = "client"
  KEY_SIGNATURE = "signature"
  KEY_REQUEST = "request"
  KEY_ENCRYPTED_REQUEST = "encrypted_request"
  KEY_RESPONSE = "response"
  KEY_ENCRYPTED_RESPONSE = "encrypted_response"
  KEY_SEQUENCE_NUMBER = "sequence_number"
  KEY_CLIENT_ID = "client_id"
  KEY_USER_EMAIL = "user_email"
  KEY_USER_PASSWORD = "user_password"
  KEY_OPERATION = "operation"
  KEY_DATUM_KEY = "datum_key"
  KEY_DATUM_VALUE = "datum_value"
  KEY_REQUEST_ID = "request_id"
  KEY_REQUEST_CLIENT = "request_client"
  KEY_DATUM_ID = "datum_id"
  KEY_ALERT_ID = "alert_id"
  KEY_TRANSACTION_ID = "transaction_id"
  KEY_USER_ID = "user_id"
  KEY_STATUS = "status"

  KEY_ACCESS_REQUEST = "access_request"
  KEY_ACCESS_REQUESTS = "access_requests"
  KEY_ALERT = "alert"
  KEY_ALERTS = "alerts"
  KEY_TRANSACTION = "transaction"
  KEY_TRANSACTIONS = "transactions"
  KEY_DATUM = "datum"
  KEY_DATUMS = "datums"
  KEY_GUID = "guid"
  KEY_NAME = "name"
  KEY_USER = "user"
  KEY_EMAIL = "email"

  OPERATION_INDEX = "index"
  OPERATION_GET = "get"
  OPERATION_POST = "post"
  OPERATION_PUT = "put"

  STATUS_PENDING = "pending"
  STATUS_COMPLETED = "completed"
  STATUS_EXPIRED = "expired"
  STATUS_APPROVED = "approved"
  STATUS_DENIED = "denied"
  STATUS_ACTIVE = "active"

  DATUM_KEY_SSN = "ssn"
  DATUM_KEY_PASSPORT_NUMBER = "passport_number"
  DATUM_KEY_DOB = "dob"
  DATUM_KEY_LICENSE_NUMBER = "license_number"
  DATUM_KEY_LICENSE_STATE = "license_state"
  DATUM_KEY_LICENSE_ISSUE = "license_issue"
  DATUM_KEY_LICENSE_EXPIRATION = "license_expiration"
  DATUM_KEY_EMAIL = "email"
  DATUM_KEY_PHONE_NUMBER = "phone_number"
  DATUM_KEY_ADDRESS = "address"
  DATUM_KEY_FIRST_NAME = "first_name"
  DATUM_KEY_MIDDLE_NAME = "middle_name"
  DATUM_KEY_LAST_NAME = "last_name"
  DATUM_KEY_OCCUPATION = "occupation"
  DATUM_KEY_EMPLOYER = "employer"

  KEY_LENGTH = 350
  SIGNATURE_LENGTH = 350
  IV_LENGTH = 16
  ENCRYPTION_LENGTH = 256
  GUID_LENGTH = 36
  MINIMUM_PASSWORD_LENGTH = 8
end
