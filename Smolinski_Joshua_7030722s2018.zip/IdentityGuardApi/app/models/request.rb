require 'openssl'
require 'base64'

class Request
  attr_reader :decrypted_hash
  def initialize(request, is_seq)
    @decrypted_hash = nil

    # Verify that parameters are not nil, empty, or the wrong length
    unless valid_request?(request)
      return
    end

    # Verify that the request is signed by the client provided
    @client = Client.find_by_guid(request[Const::KEY_CLIENT])
    unless valid_signature?(@client.public_key, request[Const::KEY_SIGNATURE], request[Const::KEY_KEY])
      return
    end

    # Decrypt the symmetric key
    encrypted_key = request[Const::KEY_KEY]
    symmetric_key = decrypt_key(encrypted_key)
    if symmetric_key.nil?
      return
    end

    # Now we have a request from a verified client and the key, decrypt the request
    request_hash = decrypt_request(request[Const::KEY_ENCRYPTED_REQUEST], symmetric_key, request[Const::KEY_SECRET])
    if request_hash.nil?
      return
    end

    # Make sure the sequence number provided is still valid
    unless is_seq
      unless valid_sequence_number?(request_hash)
        return
      end
    end

    # Add the client info to the request
    request_hash[Const::KEY_CLIENT_ID] = @client.guid

    # Make the hash available
    @decrypted_hash = request_hash
  end

  # ########################################
  # Verify that the requests are valid
  # ########################################
  def valid_request?(request)
    if !request.nil? && has_request_keys?(request) && valid_keys?(request)
      client = Client.find_by_guid(request[Const::KEY_CLIENT])
      !client.nil?
    else
      false
    end
  end

  # ########################################
  # Check the keys of the request hash
  # ########################################
  def has_request_keys?(request)
    request.size == 5 && request.has_key?(Const::KEY_CLIENT) && request.has_key?(Const::KEY_KEY) &&
        request.has_key?(Const::KEY_SECRET) && request.has_key?(Const::KEY_ENCRYPTED_REQUEST) &&
        request.has_key?(Const::KEY_SIGNATURE)
  end

  # ########################################
  # Check the values of the request hash
  # ########################################
  def valid_keys?(request)
    valid_client_key?(request) && valid_key_key?(request) && valid_secret_key?(request) &&
        valid_request_key?(request) && valid_signature_key?(request)
  end

  def valid_client_key?(request)
    !request[Const::KEY_CLIENT].blank? && request[Const::KEY_CLIENT].length == Const::GUID_LENGTH
  end

  def valid_key_key?(request)
    length = request[Const::KEY_KEY].length
    !request[Const::KEY_KEY].blank? # && request[Const::KEY_KEY].length == Const::KEY_LENGTH
  end

  def valid_secret_key?(request)
    !request[Const::KEY_SECRET].blank? # && request[Const::KEY_SECRET].length == Const::IV_LENGTH
  end

  def valid_request_key?(request)
    !request[Const::KEY_ENCRYPTED_REQUEST].blank?
  end

  def valid_signature_key?(request)
    !request[Const::KEY_SIGNATURE].blank? # && request[Const::KEY_SIGNATURE].length == Const::SIGNATURE_LENGTH
  end

  def valid_sequence_number?(request)
    if !request.nil? && request.has_key?(Const::KEY_SEQUENCE_NUMBER) && !request[Const::KEY_SEQUENCE_NUMBER].blank? &&
        request[Const::KEY_SEQUENCE_NUMBER].length == Const::GUID_LENGTH
      seq = SequenceNumber.where(guid: request[Const::KEY_SEQUENCE_NUMBER]).where(client_id: @client.guid).take
      if seq.nil?
        return false
      end

      seq.status == Const::STATUS_PENDING
    else
      false
    end
  end

  # ########################################
  # Request helper methods
  # ########################################
  def decrypt_key(encrypted_key)
    decoded_key = Base64.decode64(encrypted_key)
    private_key = OpenSSL::PKey::RSA.new(Secrets::SERVER_KEY, Secrets::DATUM_VALUE_ENCRYPTION_KEY)
    private_key.private_decrypt(decoded_key)
  end

  def decrypt_request(request, key, iv)
    decipher = OpenSSL::Cipher::AES.new(Const::ENCRYPTION_LENGTH, :CBC)
    decipher.decrypt
    decipher.key = Base64.decode64(key)
    decipher.iv = Base64.decode64(iv)
    decoded_request = Base64.decode64(request)

    plaintext = decipher.update(decoded_request) + decipher.final
    to_json(plaintext)
  end

  def valid_signature?(keyfile, signature, key)
    public_key = OpenSSL::PKey::RSA.new(keyfile, Secrets::DATUM_VALUE_ENCRYPTION_KEY)
    decoded_signature = Base64.decode64(signature)
    test_key = public_key.public_decrypt(decoded_signature)
    test_key == key[0...128]
  end

  def to_json(string)
    begin
      JSON.parse(string)
    rescue JSON::ParserError => e
      nil
    end
  end
end