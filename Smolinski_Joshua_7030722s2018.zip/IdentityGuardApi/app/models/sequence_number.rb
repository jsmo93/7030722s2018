class SequenceNumber < ActiveRecord::Base
end