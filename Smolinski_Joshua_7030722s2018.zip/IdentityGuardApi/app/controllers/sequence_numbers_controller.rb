require 'securerandom'

class SequenceNumbersController < ApplicationController
  # POST /sequence_numbers
  # POST /sequence_numbers.json
  def create
    # Get a hash of the whitelisted params
    whitelisted = sequence_number_params.to_h

    # Create a request object from the hash
    request = Request.new(whitelisted, true)

    # Retrieve the decrypted request hash and verify that it is not null
    # Parse the hash for the required keys and values
    # Perform additional validations, such as User validation, Sequence Number validation, and Datum validation
    request_hash = request.decrypted_hash
    if request_hash.nil?
      render status: :bad_request
      return
    else
      @client = Client.find_by_guid(request_hash[Const::KEY_CLIENT_ID])
      if @client.nil?
        render status: :bad_request
        return
      end
      request_hash = request_hash.except(Const::KEY_CLIENT_ID)
    end

    unless valid_request?(request_hash)
      render status: :bad_request
      return
    end

    # Process the request
    plain_response = process_request(request_hash)

    # Validate that the request was processed successfully
    if plain_response.nil?
      render status: :bad_request
      return
    end

    # Create a response object from the hash
    response = Response.new(plain_response, @client.guid, true)

    # Retrieve the encrypted hash
    response_hash = response.response_hash

    # Render it as JSON
    render :json => response_hash.to_json
  end

  private
    # ########################################
    # Verify that the requests are valid
    # ########################################
    def valid_request?(request)
      if !request.nil? && has_request_keys?(request) && valid_operation_key?(request)
        sequence_number = SequenceNumber.where(client_id: @client.guid).where(status: Const::STATUS_PENDING).take
        sequence_number.nil?
      else
        false
      end
    end

    # ########################################
    # Check the keys of the request hash
    # ########################################
    def has_request_keys?(request)
      request.size == 1 && request.has_key?(Const::KEY_OPERATION)
    end

    # ########################################
    # Check the values of the request hash
    # ########################################
    def valid_operation_key?(request)
      !request[Const::KEY_OPERATION].blank? && request[Const::KEY_OPERATION] == Const::OPERATION_POST
    end

    # ########################################
    # Process the actual request
    # ########################################
    def process_request(request)
      seq_guid = SecureRandom.uuid
      sequence_number = SequenceNumber.create(guid: seq_guid, client_id: @client.guid, status: Const::STATUS_PENDING)
      object = {}
      object[Const::KEY_GUID] = sequence_number.guid
      response = {}
      response[Const::KEY_SEQUENCE_NUMBER] = object
      response
    end

    # ########################################
    # Response helper methods
    # ########################################
    def to_json(string)
      begin
        JSON.parse(string)
      rescue JSON::ParserError
        nil
      end
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def sequence_number_params
      params.require(:request).permit(:client, :key, :secret, :encrypted_request, :signature)
    end
end
