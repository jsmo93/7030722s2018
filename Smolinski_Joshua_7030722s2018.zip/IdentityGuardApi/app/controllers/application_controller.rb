require 'openssl'

class ApplicationController < ActionController::API
end
