require 'mail'
require 'securerandom'

class TransactionsController < ApplicationController
  # POST /transactions
  # POST /transactions.json
  def create
    # Get a hash of the whitelisted params
    whitelisted = transaction_params.to_h

    # Create a request object from the hash
    request = Request.new(whitelisted, false)

    # Retrieve the decrypted request hash and verify that it is not null
    # Parse the hash for the required keys and values
    # Perform additional validations, such as User validation, Sequence Number validation, and Datum validation
    request_hash = request.decrypted_hash
    if request_hash.nil?
      render status: :bad_request
      return
    else
      @client = Client.find_by_guid(request_hash[Const::KEY_CLIENT_ID])
      if @client.nil?
        render status: :bad_request
        return
      end
      request_hash = request_hash.except(Const::KEY_CLIENT_ID)
    end

    unless valid_request?(request_hash)
      render status: :bad_request
      return
    end

    # If this is a user request, validate that this client key is approved to access data
    # If this is a user request, validate the user password
    # Process the request
    user = User.find_by_email(request_hash[Const::KEY_USER_EMAIL])
    if user_request?(request_hash)
      unless Secrets::USER_CLIENT_ID == @client.guid &&
          user.authenticate(request_hash[Const::KEY_USER_PASSWORD])
        render status: :unauthorized
        return
      end
    end
    plain_response = process_request(request_hash)

    # Validate that the request was processed successfully
    if plain_response.nil?
      render status: :bad_request
      return
    end

    sequence_number = SequenceNumber.find_by_guid(request_hash[Const::KEY_SEQUENCE_NUMBER])
    sequence_number.status = Const::STATUS_COMPLETED
    sequence_number.save

    # Create a response object from the hash
    response = Response.new(plain_response, @client.guid, false)

    # Retrieve the encrypted hash
    response_hash = response.response_hash

    # Render it as JSON
    render :json => response_hash.to_json
  end

  private
    # ########################################
    # Verify that the requests are valid
    # ########################################
    def valid_request?(request)
      if request[Const::KEY_OPERATION] == Const::OPERATION_INDEX
          valid_index_request?(request)
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_GET
          valid_get_request?(request)
      else
        false
      end
    end

    def valid_index_request?(request)
      if !request.nil? && has_index_request_keys?(request) && valid_index_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the user exists
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            !user.nil?
          end
        end
      else
        false
      end
    end

    def valid_get_request?(request)
      if !request.nil? && has_get_request_keys?(request) && valid_get_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the transaction exists and that the user owns it
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            if user.nil?
              false
            else
              transaction = Transaction.where(guid: request[Const::KEY_TRANSACTION_ID]).where(user_id: user.guid).take
              !transaction.nil?
            end
          end
        end
      else
        false
      end
    end

    def user_request?(request)
      request.has_key?(Const::KEY_USER_PASSWORD)
    end
    # ########################################
    # Check the keys of the request hash
    # ########################################

    def has_index_request_keys?(request)
      request.size == 4 && has_common_keys?(request)
    end

    def has_get_request_keys?(request)
      request.size == 5 && has_common_keys?(request) && request.has_key?(Const::KEY_TRANSACTION_ID)
    end

    def has_common_keys?(request)
      request.has_key?(Const::KEY_OPERATION) && request.has_key?(Const::KEY_SEQUENCE_NUMBER) &&
          request.has_key?(Const::KEY_USER_EMAIL) && request.has_key?(Const::KEY_USER_PASSWORD)
    end

    # ########################################
    # Check the values of the request hash
    # ########################################

    def valid_index_keys?(request)
      valid_common_keys?(request)
    end

    def valid_get_keys?(request)
      valid_common_keys?(request) && valid_transaction_id_key?(request)
    end

    def valid_common_keys?(request)
      valid_operation_key?(request) && valid_sequence_number_key?(request) && valid_email_key?(request) && valid_password_key?(request)
    end

    def valid_operation_key?(request)
      !request[Const::KEY_OPERATION].blank? &&
          (request[Const::KEY_OPERATION] == Const::OPERATION_INDEX ||
              request[Const::KEY_OPERATION] == Const::OPERATION_GET)
    end

    def valid_sequence_number_key?(request)
      !request[Const::KEY_SEQUENCE_NUMBER].blank? && request[Const::KEY_SEQUENCE_NUMBER].length == Const::GUID_LENGTH
    end

    def valid_email_key?(request)
      !request[Const::KEY_USER_EMAIL].blank? && to_email(request[Const::KEY_USER_EMAIL])
    end

    def valid_password_key?(request)
      !request[Const::KEY_USER_PASSWORD].blank? &&
          request[Const::KEY_USER_PASSWORD].length >= Const::MINIMUM_PASSWORD_LENGTH
    end

    def valid_transaction_id_key?(request)
      !request[Const::KEY_TRANSACTION_ID].blank? && request[Const::KEY_TRANSACTION_ID].length == Const::GUID_LENGTH
    end

    # ########################################
    # Process the actual request
    # ########################################

    def process_request(request)
      if request[Const::KEY_OPERATION] == Const::OPERATION_INDEX
        process_index_request(request)
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_GET
        process_get_request(request)
      end
    end

    def process_index_request(request)
      user = User.find_by_email(request[Const::KEY_USER_EMAIL])
      transaction = Transaction.where(user_id: user.guid).pluck(Const::KEY_GUID)
      response = {}
      response[Const::KEY_TRANSACTIONS] = transaction.to_a
      response
    end

    def process_get_request(request)
      transaction = Transaction.find_by_guid(request[Const::KEY_TRANSACTION_ID])
      client = Client.find_by_guid(transaction.client_id)
      object = {}
      object[Const::KEY_GUID] = transaction.guid
      object[Const::KEY_CLIENT] = client.name
      object[Const::KEY_DATUM_ID] = transaction.datum_id
      response = {}
      response[Const::KEY_TRANSACTION] = object
      response
    end

    # ########################################
    # Response helper methods
    # ########################################

    def to_json(string)
      begin
        JSON.parse(string)
      rescue JSON::ParserError
        nil
      end
    end

    def to_email(string)
      address = ValidEmail2::Address.new(string)
      res = address.valid?
      res
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def transaction_params
      params.require(:request).permit(:client, :key, :secret, :encrypted_request, :signature)
    end
end
