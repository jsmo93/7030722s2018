require 'mail'
require 'securerandom'

class UsersController < ApplicationController
  # POST /users
  # POST /users.json
  def create
    # Get a hash of the whitelisted params
    whitelisted = user_params.to_h

    # Create a request object from the hash
    request = Request.new(whitelisted, false)

    # Retrieve the decrypted request hash and verify that it is not null
    # Parse the hash for the required keys and values
    # Perform additional validations, such as User validation, Sequence Number validation, and Datum validation
    request_hash = request.decrypted_hash
    if request_hash.nil?
      render status: :bad_request
      return
    else
      @client = Client.find_by_guid(request_hash[Const::KEY_CLIENT_ID])
      if @client.nil?
        render status: :bad_request
        return
      end
      request_hash = request_hash.except(Const::KEY_CLIENT_ID)
    end

    unless valid_request?(request_hash)
      render status: :bad_request
      return
    end

    # Validate that this client key is approved to create users
    # Process the request
    unless Secrets::USER_CLIENT_ID == @client.guid
      render status: :unauthorized
      return
    end
    plain_response = process_request(request_hash)

    # Validate that the request was processed successfully
    if plain_response.nil?
      render status: :bad_request
      return
    end

    sequence_number = SequenceNumber.find_by_guid(request_hash[Const::KEY_SEQUENCE_NUMBER])
    sequence_number.status = Const::STATUS_COMPLETED
    sequence_number.save

    # Create a response object from the hash
    response = Response.new(plain_response, @client.guid, false)

    # Retrieve the encrypted hash
    response_hash = response.response_hash

    # Render it as JSON
    render :json => response_hash.to_json
  end

  private
    # ########################################
    # Verify that the requests are valid
    # ########################################
    def valid_request?(request)
      if !request.nil? && has_request_keys?(request) && valid_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that there isn't already a user with that email
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            user.nil?
          end
        end
      else
        false
      end
    end

    # ########################################
    # Check the keys of the request hash
    # ########################################

    def has_request_keys?(request)
      request.size == 4 && request.has_key?(Const::KEY_OPERATION) && request.has_key?(Const::KEY_SEQUENCE_NUMBER) &&
          request.has_key?(Const::KEY_USER_EMAIL) && request.has_key?(Const::KEY_USER_PASSWORD)
    end

    # ########################################
    # Check the values of the request hash
    # ########################################

    def valid_keys?(request)
      valid_operation_key?(request) && valid_sequence_number_key?(request) && valid_email_key?(request) &&
          valid_password_key?(request)
    end

    def valid_operation_key?(request)
      !request[Const::KEY_OPERATION].blank? && request[Const::KEY_OPERATION] == Const::OPERATION_POST
    end

    def valid_sequence_number_key?(request)
      !request[Const::KEY_SEQUENCE_NUMBER].blank? && request[Const::KEY_SEQUENCE_NUMBER].length == Const::GUID_LENGTH
    end
  
    def valid_email_key?(request)
      !request[Const::KEY_USER_EMAIL].blank? && to_email(request[Const::KEY_USER_EMAIL])
    end
  
    def valid_password_key?(request)
      !request[Const::KEY_USER_PASSWORD].blank? &&
          request[Const::KEY_USER_PASSWORD].length >= Const::MINIMUM_PASSWORD_LENGTH
    end

    # ########################################
    # Process the actual request
    # ########################################

    def process_request(request)
      user_guid = SecureRandom.uuid
      user = User.create(guid: user_guid, email: request[Const::KEY_USER_EMAIL], password: request[Const::KEY_USER_PASSWORD])
      object = {}
      object[Const::KEY_EMAIL] = user.email
      response = {}
      response[Const::KEY_USER] = object
      response
    end

    # ########################################
    # Response helper methods
    # ########################################

    def to_json(string)
      begin
        JSON.parse(string)
      rescue JSON::ParserError
        nil
      end
    end

    def to_email(string)
      address = ValidEmail2::Address.new(string)
      res = address.valid?
      res
    end
  
    # Never trust parameters from the scary internet, only allow the white list through.
    def user_params
      params.require(:request).permit(:client, :key, :secret, :encrypted_request, :signature)
    end
end
