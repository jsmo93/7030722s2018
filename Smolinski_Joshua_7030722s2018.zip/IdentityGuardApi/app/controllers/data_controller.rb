require 'mail'
require 'openssl'
require 'securerandom'

class DataController < ApplicationController
  # POST /data
  # POST /data.json
  def create
    # Get a hash of the whitelisted params
    whitelisted = datum_params.to_h

    # Create a request object from the hash
    request = Request.new(whitelisted, false)

    # Retrieve the decrypted request hash and verify that it is not null
    # Parse the hash for the required keys and values
    # Perform additional validations, such as User validation, Sequence Number validation, and Datum validation
    request_hash = request.decrypted_hash
    if request_hash.nil?
      render status: :bad_request
      return
    else
      @client = Client.find_by_guid(request_hash[Const::KEY_CLIENT_ID])
      if @client.nil?
        render status: :bad_request
        return
      end
      request_hash = request_hash.except(Const::KEY_CLIENT_ID)
    end

    unless valid_request?(request_hash)
      render status: :bad_request
      return
    end

    # If this is a user request, validate that this client key is approved to access data
    # If this is a user request, validate the user password
    # Process the request
    user = User.find_by_email(request_hash[Const::KEY_USER_EMAIL])
    if user_request?(request_hash)
      unless Secrets::USER_CLIENT_ID == @client.guid &&
          user.authenticate(request_hash[Const::KEY_USER_PASSWORD])
        render status: :unauthorized
        return
      end
    else
      access = AccessRequest.where(client_id: @client.guid).where(user_id: user.guid).where(datum_key: request_hash[Const::KEY_DATUM_KEY]).take
      if access.nil? || access.status != Const::STATUS_APPROVED
        render status: :unauthorized
        return
      end
    end
    plain_response = process_request(request_hash)

    # Validate that the request was processed successfully
    if plain_response.nil?
      render status: :bad_request
      return
    end

    sequence_number = SequenceNumber.find_by_guid(request_hash[Const::KEY_SEQUENCE_NUMBER])
    sequence_number.status = Const::STATUS_COMPLETED
    sequence_number.save

    # Create a response object from the hash
    response = Response.new(plain_response, @client.guid, false)

    # Retrieve the encrypted hash
    response_hash = response.response_hash

    # Render it as JSON
    render :json => response_hash.to_json
  end

  private
    # ########################################
    # Verify that the requests are valid
    # ########################################
    def valid_request?(request)
      if request[Const::KEY_OPERATION] == Const::OPERATION_INDEX && user_request?(request)
        valid_user_index_request?(request)
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_GET
        if user_request?(request)
          valid_user_get_request?(request)
        else
          valid_client_request?(request)
        end
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_POST && user_request?(request)
        valid_user_post_request?(request)
      else
        false
      end
    end
        
    def valid_user_index_request?(request)
      if !request.nil? && has_user_index_request_keys?(request) && valid_user_index_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the user exists
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            !user.nil?
          end
        end
      else
        false
      end
    end
  
    def valid_user_get_request?(request)
      if !request.nil? && has_user_get_request_keys?(request) && valid_user_get_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the datum exists for the user
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            if user.nil?
              false
            else
              datum = Datum.where(guid: request[Const::KEY_DATUM_ID]).where(user_id: user.guid).take
              !datum.nil?
            end
          end
        end
      else
        false
      end
    end
  
    def valid_user_post_request?(request)
      if !request.nil? && has_user_post_request_keys?(request) && valid_user_post_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the datum does not already exist for the user
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            if user.nil?
              false
            else
              datum = Datum.where(user_id: user.guid).where(key: request[Const::KEY_DATUM_KEY]).take
              datum.nil?
            end
          end
        end
      else
        false
      end
    end
  
    def valid_client_request?(request)
      if !request.nil? && has_client_request_keys?(request) && valid_client_keys?(request)
        sequence_number = SequenceNumber.find_by_guid(request[Const::KEY_SEQUENCE_NUMBER])
        if sequence_number.nil?
          false
        else
          # Verify that the provided sequence number has not been used yet
          if sequence_number.status != Const::STATUS_PENDING
            false
          else
            # Verify that the datum exists for the user
            user = User.find_by_email(request[Const::KEY_USER_EMAIL])
            if user.nil?
              false
            else
              datum = Datum.where(user_id: user.guid).where(key: request[Const::KEY_DATUM_KEY]).take
              !datum.nil?
            end
          end
        end
      else
        false
      end
    end

    def user_request?(request)
      request.has_key?(Const::KEY_USER_PASSWORD)
    end

    # ########################################
    # Check the keys of the request hash
    # ########################################

    def has_user_index_request_keys?(request)
      request.size == 4 && has_common_keys?(request) && request.has_key?(Const::KEY_USER_PASSWORD)
    end
  
    def has_user_get_request_keys?(request)
      request.size == 5 && has_common_keys?(request) && request.has_key?(Const::KEY_USER_PASSWORD) &&
          request.has_key?(Const::KEY_DATUM_ID)
    end
  
    def has_user_post_request_keys?(request)
      request.size == 6 && has_common_keys?(request) && request.has_key?(Const::KEY_USER_PASSWORD) &&
          request.has_key?(Const::KEY_DATUM_KEY) && request.has_key?(Const::KEY_DATUM_VALUE)
    end
  
    def has_client_request_keys?(request)
      request.size == 4 && has_common_keys?(request) && request.has_key?(Const::KEY_DATUM_KEY)
    end

    def has_common_keys?(request)
      request.has_key?(Const::KEY_OPERATION) && request.has_key?(Const::KEY_SEQUENCE_NUMBER) &&
          request.has_key?(Const::KEY_USER_EMAIL)
    end

    # ########################################
    # Check the values of the request hash
    # ########################################
    def valid_user_index_keys?(request)
      valid_common_keys?(request) && valid_password_key?(request)
    end

    def valid_user_get_keys?(request)
      valid_common_keys?(request) && valid_password_key?(request) && valid_datum_id_key?(request)
    end

    def valid_user_post_keys?(request)
      valid_common_keys?(request) && valid_password_key?(request) && valid_datum_key_key?(request) &&
          valid_datum_value_key?(request)
    end

    def valid_client_keys?(request)
      valid_common_keys?(request) && valid_datum_key_key?(request)
    end

    def valid_common_keys?(request)
      valid_operation_key?(request) && valid_sequence_number_key?(request) && valid_email_key?(request)
    end

    def valid_operation_key?(request)
      !request[Const::KEY_OPERATION].blank? &&
          (request[Const::KEY_OPERATION] == Const::OPERATION_INDEX ||
              request[Const::KEY_OPERATION] == Const::OPERATION_GET ||
              request[Const::KEY_OPERATION] == Const::OPERATION_POST)
    end

    def valid_sequence_number_key?(request)
      !request[Const::KEY_SEQUENCE_NUMBER].blank? &&
          request[Const::KEY_SEQUENCE_NUMBER].length == Const::GUID_LENGTH
    end

    def valid_email_key?(request)
      !request[Const::KEY_USER_EMAIL].blank? && to_email(request[Const::KEY_USER_EMAIL])
    end

    def valid_password_key?(request)
      !request[Const::KEY_USER_PASSWORD].blank? &&
          request[Const::KEY_USER_PASSWORD].length >= Const::MINIMUM_PASSWORD_LENGTH
    end

    def valid_datum_key_key?(request)
      !request[Const::KEY_DATUM_KEY].blank? &&
          (request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_SSN ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_PASSPORT_NUMBER ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_DOB ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_LICENSE_NUMBER ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_LICENSE_STATE ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_LICENSE_ISSUE ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_LICENSE_EXPIRATION ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_EMAIL ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_PHONE_NUMBER ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_ADDRESS ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_FIRST_NAME ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_MIDDLE_NAME ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_LAST_NAME ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_OCCUPATION ||
              request[Const::KEY_DATUM_KEY] == Const::DATUM_KEY_EMPLOYER)
    end

    def valid_datum_value_key?(request)
      !request[Const::KEY_DATUM_VALUE].blank?
    end

    def valid_datum_id_key?(request)
      !request[Const::KEY_DATUM_ID].blank? && request[Const::KEY_DATUM_ID].length == Const::GUID_LENGTH
    end

    # ########################################
    # Process the actual request
    # ########################################
    def process_request(request)
      if user_request?(request)
        process_user_request(request)
      else
        process_client_request(request)
      end
    end

    def process_user_request(request)
      if request[Const::KEY_OPERATION] == Const::OPERATION_INDEX
        process_user_index_request(request)
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_GET
        process_user_get_request(request)
      elsif request[Const::KEY_OPERATION] == Const::OPERATION_POST
        process_user_post_request(request)
      end
    end

    def process_user_index_request(request)
      user = User.find_by_email(request[Const::KEY_USER_EMAIL])
      data = Datum.where(user_id: user.guid).pluck(Const::KEY_GUID)
      response = {}
      response[Const::KEY_DATUMS] = data.to_a
      response
    end

    def process_user_get_request(request)
      datum = Datum.find_by_guid(request[Const::KEY_DATUM_ID])
      object = {}
      object[datum.key] = decrypt_value(datum.value, datum.iv)
      response = {}
      response[Const::KEY_DATUM] = object
      response
    end

    def process_user_post_request(request)
      user = User.find_by_email(request[Const::KEY_USER_EMAIL])
      datum_guid = SecureRandom.uuid
      secure_hash = encrypt_value(request[Const::KEY_DATUM_VALUE])
      datum = Datum.create(guid: datum_guid, user_id: user.guid, key: request[Const::KEY_DATUM_KEY], value: secure_hash[Const::KEY_DATUM_VALUE], iv: secure_hash[Const::KEY_SECRET])
      object = {}
      object[Const::KEY_GUID] = datum.guid
      response = {}
      response[Const::KEY_DATUM] = object
      response
    end

    def process_client_request(request)
      user = User.find_by_email(request[Const::KEY_USER_EMAIL])
      datum = Datum.where(user_id: user.guid).where(key: request[Const::KEY_DATUM_KEY]).take
      object = {}
      object[datum.key] = decrypt_value(datum.value, datum.iv)
      response = {}
      response[Const::KEY_DATUM] = object

      # Before returning the response, record what they client obtained during this request
      trans_guid = SecureRandom.uuid
      Transaction.create(guid: trans_guid, client_id: @client.guid, user_id: user.guid, datum_id: datum.guid)

      response
    end

    # ########################################
    # Response helper methods
    # ########################################
    def to_json(string)
      begin
        JSON.parse(string)
      rescue JSON::ParserError
        nil
      end
    end

    def to_email(string)
      address = ValidEmail2::Address.new(string)
      res = address.valid?
      res
    end

    def encrypt_value(value)
      iv = SecureRandom.hex(8)

      cipher = OpenSSL::Cipher::AES.new(Const::ENCRYPTION_LENGTH, :CBC)
      cipher.encrypt
      cipher.key = Secrets::DATUM_VALUE_ENCRYPTION_KEY
      cipher.iv = iv

      decoded = cipher.update(value) + cipher.final
      encoded = Base64.encode64(decoded)

      secure_hash = {}
      secure_hash[Const::KEY_DATUM_VALUE] = encoded
      secure_hash[Const::KEY_SECRET] = iv
      secure_hash
    end

    def decrypt_value(encoded_value, iv)
      decipher = OpenSSL::Cipher::AES.new(Const::ENCRYPTION_LENGTH, :CBC)
      decipher.decrypt
      decipher.key = Secrets::DATUM_VALUE_ENCRYPTION_KEY
      decipher.iv = iv

      decoded = Base64.decode64(encoded_value)
      decipher.update(decoded) + decipher.final
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def datum_params
      params.require(:request).permit(:client, :key, :secret, :encrypted_request, :signature)
    end
end
