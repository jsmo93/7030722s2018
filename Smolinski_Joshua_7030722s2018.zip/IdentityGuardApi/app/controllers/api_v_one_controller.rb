class ApiVOneController < ApplicationController
  def index
    render status: :unauthorized
  end
end