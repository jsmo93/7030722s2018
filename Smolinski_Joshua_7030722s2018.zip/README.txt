Installing the Android Application from Android Studio:
1) Download and install Android Studio using these instructions: https://developer.android.com/studio/install
2) Select "Open an Existing Android Studio project" and point to the IdentityGuardApp folder.
3) Android Studio will begin loading the application. If you see a message which says that you are missing a version of the SDK or Build Tools, click the install link provided in the error. Ignore any requests to upgrade the projects Gradle version.
4) Turn on an Android device running Android 6.0 (Marshmallow) or later. Enable USB Debugging as described here: https://developer.android.com/studio/debug/dev-options
5) Plug in the device and press the run (or play) button to launch the app. You may be asked if you trust the computer to be used as a debugger, press the yes button
6) Make sure that the device is connected to the same network as the server
Note: The app may look distorted on smaller or lower resolution screens.

Installing the Rails Application using RubyMine:
1) Follow this tutorial to install the Ruby Version Monitor (RVM), stop at the section labeled "Rails", do not do "gem install rails --version 5.0.0": http://blog.teamtreehouse.com/installing-rails-5-linux
2) In the terminal now setup for login shell, navigate into the IdentityGuardApi folder
3) Type 'gem install bundler' to install the bundler
4) When the installation finishes, type 'bundle install --path ./local_gems', this will create a local gems folder and install the gems needed to use the server
5) When the installation finishes, type 'rake db:drop db:create db:migrate db:seed', this will create a new database and seed it with the client information built into the android app
6) When the database setup is finished, type 'rails s', this will start the server in development mode
7) In another terminal window, type 'ifconfig' and record the IP Address of the machine. The app must be pointed to the server using this address