package com.jsmolinski.identityguard.View.Interfaces;

import com.jsmolinski.identityguard.Data.Models.Datum;

public interface OnRequestActionInterface {
    void onRequestApproved(String client, Datum.DatumKey key);
    void onRequestDenied(String client, Datum.DatumKey key);
}
