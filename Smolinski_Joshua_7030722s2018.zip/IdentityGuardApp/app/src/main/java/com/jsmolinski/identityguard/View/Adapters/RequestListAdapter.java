package com.jsmolinski.identityguard.View.Adapters;

import android.content.Context;
import android.graphics.PorterDuff;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.Data.Models.AccessRequest;
import com.jsmolinski.identityguard.R;
import com.jsmolinski.identityguard.View.Interfaces.OnRequestActionInterface;

import java.util.List;

public class RequestListAdapter extends RecyclerView.Adapter<RequestListAdapter.ViewHolder> {
    private List<RequestModelView> mRequestModelViewList;
    private Context mContext;
    private OnRequestActionInterface mInterface;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public View mView;

        public ViewHolder(View v) {
            super(v);
            mView = v;
        }
    }

    public RequestListAdapter(List<RequestModelView> requestModelViewList, Context context, OnRequestActionInterface actionInterface) {
        mContext = context;
        mRequestModelViewList = requestModelViewList;
        mInterface = actionInterface;
    }

    @Override
    public RequestListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
        View view;
        if (viewType == ViewType.SYSTEM_HEADER.getValue()) {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_header_primary, parent, false);
        } else if (viewType == ViewType.CLIENT_HEADER.getValue()) {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_header_client, parent, false);
        } else if (viewType == ViewType.PENDING_ITEM.getValue()) {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_item_pending, parent, false);
        } else {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_item_past, parent, false);
        }

        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        RequestModelView requestModelView = mRequestModelViewList.get(position);
        TextView textView;
        if (requestModelView.getViewType() == ViewType.SYSTEM_HEADER) {
            textView = holder.mView.findViewById(R.id.text_view_header);
            textView.setText(requestModelView.getPrimaryText());
        } else if (requestModelView.getViewType() == ViewType.CLIENT_HEADER) {
            textView = holder.mView.findViewById(R.id.text_view_header);
            textView.setText(requestModelView.getClient());
            if (requestModelView.getDrawableId() != null) {
                ImageView img = holder.mView.findViewById(R.id.img_client);
                img.setImageDrawable(mContext.getDrawable(requestModelView.getDrawableId()));
            }
        } else if (requestModelView.getViewType() == ViewType.PENDING_ITEM) {
            textView = holder.mView.findViewById(R.id.text_view_item);
            textView.setText(Datum.getDisplayName(requestModelView.getKey()));
            Button low = holder.mView.findViewById(R.id.btn_approve_low);
            low.setOnClickListener(v -> mInterface.onRequestApproved(requestModelView.getClient(), requestModelView.getKey()));
            Button medium = holder.mView.findViewById(R.id.btn_approve_medium);
            medium.setOnClickListener(v -> mInterface.onRequestApproved(requestModelView.getClient(), requestModelView.getKey()));
            Button high = holder.mView.findViewById(R.id.btn_approve_high);
            high.setOnClickListener(v -> mInterface.onRequestApproved(requestModelView.getClient(), requestModelView.getKey()));
            Button deny = holder.mView.findViewById(R.id.btn_decline);
            deny.setOnClickListener(v -> mInterface.onRequestDenied(requestModelView.getClient(), requestModelView.getKey()));
            Datum.Sensativity sensativity = requestModelView.getSensativity();
            if (sensativity == Datum.Sensativity.LOW){
                low.setVisibility(View.VISIBLE);
                medium.setVisibility(View.INVISIBLE);
                high.setVisibility(View.INVISIBLE);
            } else if (sensativity == Datum.Sensativity.MEDIUM){
                low.setVisibility(View.INVISIBLE);
                medium.setVisibility(View.VISIBLE);
                high.setVisibility(View.INVISIBLE);
            } else {
                low.setVisibility(View.INVISIBLE);
                medium.setVisibility(View.INVISIBLE);
                high.setVisibility(View.VISIBLE);
            }
        } else {
            textView = holder.mView.findViewById(R.id.text_view_item);
            textView.setText(Datum.getDisplayName(requestModelView.getKey()));
            if (requestModelView.getStatus() == AccessRequest.RequestStatus.APPROVED) {
                Integer ringDrawable = getDrawableRingForSensativity(requestModelView.getSensativity());
                Integer color = getColorForSensativity(requestModelView.getSensativity());
                if (ringDrawable != null && color != null) {
                    ImageView img = holder.mView.findViewById(R.id.img_status);
                    img.setImageDrawable(mContext.getDrawable(R.drawable.ic_lock_open_white_48pt));
                    img.setBackground(mContext.getDrawable(ringDrawable));
                    img.setColorFilter(mContext.getColor(color), PorterDuff.Mode.SRC_IN);
                }
            } else {
                ImageView img = holder.mView.findViewById(R.id.img_status);
                img.setImageDrawable(mContext.getDrawable(R.drawable.ic_close_white_48dp));
                img.setBackground(mContext.getDrawable(R.drawable.white_ring_item));
                img.setColorFilter(mContext.getColor(R.color.colorPastDeclined), PorterDuff.Mode.SRC_IN);
            }
        }
    }

    @Override
    public int getItemCount() {
        return mRequestModelViewList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return mRequestModelViewList.get(position).getViewType().getValue();
    }

    public Integer getDrawableRingForSensativity(Datum.Sensativity sensativity){
        if (sensativity == Datum.Sensativity.LOW){
            return R.drawable.green_ring_item;
        } else if (sensativity == Datum.Sensativity.MEDIUM) {
            return R.drawable.yellow_ring_item;
        } else if (sensativity == Datum.Sensativity.HIGH){
            return R.drawable.orange_ring_item;
        } else {
            return null;
        }
    }

    public Integer getColorForSensativity(Datum.Sensativity sensativity){
        if (sensativity == Datum.Sensativity.LOW){
            return R.color.colorPastSensativityLow;
        } else if (sensativity == Datum.Sensativity.MEDIUM) {
            return R.color.colorPastSensativityMedium;
        } else if (sensativity == Datum.Sensativity.HIGH){
            return R.color.colorPastSensativityHigh;
        } else {
            return null;
        }
    }

    public static class RequestModelView {
        ViewType mViewType;
        String mPrimaryText;
        String mClient;
        Datum.DatumKey mKey;
        AccessRequest.RequestStatus mStatus;
        Datum.Sensativity mSensativity;
        Integer mDrawableId;

        public RequestModelView(String primaryText){
            mViewType = ViewType.SYSTEM_HEADER;
            mPrimaryText = primaryText;
        }

        public RequestModelView(String client, Integer drawableId){
            mViewType = ViewType.CLIENT_HEADER;
            mClient = client;
            mDrawableId = drawableId;
        }

        public RequestModelView(String client, Datum.DatumKey key, AccessRequest.RequestStatus status, Datum.Sensativity sensativity) {
            mViewType = status == AccessRequest.RequestStatus.PENDING ? ViewType.PENDING_ITEM : ViewType.PAST_ITEM;
            mKey = key;
            mClient = client;
            mStatus = status;
            mSensativity = sensativity;
        }

        public ViewType getViewType() {
            return mViewType;
        }

        public String getPrimaryText() {
            return mPrimaryText;
        }

        public String getClient(){
            return mClient;
        }

        public Datum.DatumKey getKey(){
            return mKey;
        }

        public AccessRequest.RequestStatus getStatus() {
            return mStatus;
        }

        public Datum.Sensativity getSensativity(){
            return mSensativity;
        }

        public Integer getDrawableId() {
            return mDrawableId;
        }
    }

    public enum ViewType {
        SYSTEM_HEADER(0),
        CLIENT_HEADER(1),
        PENDING_ITEM(2),
        PAST_ITEM(3);

        int value;

        ViewType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
    

}
