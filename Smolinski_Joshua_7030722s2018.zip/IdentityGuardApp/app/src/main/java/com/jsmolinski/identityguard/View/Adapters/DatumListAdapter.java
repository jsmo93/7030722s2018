package com.jsmolinski.identityguard.View.Adapters;

import android.content.Context;
import android.graphics.PorterDuff;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.R;
import com.jsmolinski.identityguard.View.Interfaces.OnDataAddedInterface;

import java.util.List;

public class DatumListAdapter extends RecyclerView.Adapter<DatumListAdapter.ViewHolder> {
    private List<DatumModelView> mDatumModelViewList;
    private Context mContext;
    private OnDataAddedInterface mInterface;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public View mView;

        public ViewHolder(View v) {
            super(v);
            mView = v;
        }
    }

    public DatumListAdapter(List<DatumModelView> datumModelViewList, Context context, OnDataAddedInterface dataAddedInterface) {
        mContext = context;
        mDatumModelViewList = datumModelViewList;
        mInterface = dataAddedInterface;
    }

    @Override
    public DatumListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {
        View view;
        if (viewType == ViewType.ITEM_DISPLAY.getValue()) {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_item_display, parent, false);
        } else {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_item_entry, parent, false);
        }

        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        DatumModelView requestModelView = mDatumModelViewList.get(position);
        TextView textView;
        if (requestModelView.getViewType() == ViewType.ITEM_DISPLAY) {
            textView = holder.mView.findViewById(R.id.text_datum_key);
            textView.setText(Datum.getDisplayName(requestModelView.getKey()));
            textView = holder.mView.findViewById(R.id.text_datum_value);
            if (requestModelView.getDisplayed()) {
                textView.setText(requestModelView.getValue());
            } else {
                textView.setText("Content Hidden");
            }
            Button btn = holder.mView.findViewById(R.id.btn_display);
            if (requestModelView.getDisplayed()){
                btn.setText("Hide");
            } else {
                btn.setText("Show");
            }
            btn.setOnClickListener(v -> {
                TextView text = holder.mView.findViewById(R.id.text_datum_value);
                if (requestModelView.getDisplayed()){
                    text.setText("Content Hidden");
                    btn.setText("Show");
                } else {
                    text.setText(requestModelView.getValue());
                    btn.setText("Hide");
                }
                requestModelView.toggleDisplayed();
            });
        } else {
            textView = holder.mView.findViewById(R.id.text_datum_key);
            textView.setText(Datum.getDisplayName(requestModelView.getKey()));
            EditText edit = holder.mView.findViewById(R.id.text_datum_value);
            edit.getBackground().setColorFilter(mContext.getColor(R.color.colorWhite), PorterDuff.Mode.SRC_IN);
            Button btn = holder.mView.findViewById(R.id.btn_set);
            btn.setOnClickListener(v -> mInterface.onDataAdded(new Datum(requestModelView.getKey(), edit.getText().toString())));
        }
    }

    @Override
    public int getItemCount() {
        return mDatumModelViewList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return mDatumModelViewList.get(position).getViewType().getValue();
    }

    public static class DatumModelView {
        ViewType mViewType;
        Datum.DatumKey mKey;
        String mValue;
        boolean mDisplayed = false;

        public DatumModelView(ViewType viewType, Datum.DatumKey key, String value) {
            mViewType = viewType;
            mKey = key;
            mValue = value;
        }

        public ViewType getViewType() {
            return mViewType;
        }

        public Datum.DatumKey getKey() {
            return mKey;
        }

        public String getValue() {
            return mValue;
        }

        public boolean getDisplayed(){
            return mDisplayed;
        }

        public void toggleDisplayed(){
            mDisplayed = !mDisplayed;
        }
    }

    public enum ViewType {
        ITEM_DISPLAY(0),
        ITEM_ENTRY(1);

        int value;

        ViewType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
}
