package com.jsmolinski.identityguard.Network.Models.Responses;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Datums {
    @SerializedName("datums")
    List<String> datumGuids;

    public Datums(List<String> datumGuids){
        this.datumGuids = datumGuids;
    }
}
