package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

public class EncryptedResponse {
    @SerializedName("key")
    public String key;

    @SerializedName("secret")
    public String secret;

    @SerializedName("encrypted_response")
    public String response;

    @SerializedName("signature")
    public String signature;

    public EncryptedResponse(String key, String secret, String response, String signature){
        this.key = key;
        this.secret = secret;
        this.response = response;
        this.signature = signature;
    }
}
