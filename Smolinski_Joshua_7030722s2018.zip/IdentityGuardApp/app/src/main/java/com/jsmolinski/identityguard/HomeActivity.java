package com.jsmolinski.identityguard;

import android.app.FragmentManager;
import android.graphics.PorterDuff;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.jsmolinski.identityguard.Network.ApiAdapter;
import com.jsmolinski.identityguard.Network.NetworkManager;
import com.jsmolinski.identityguard.View.Interfaces.OnDataChangedInterface;

public class HomeActivity extends AppCompatActivity {
    private BaseFragment mCurrentFragment = null;
    private BottomNavigationView mNavigationView;
    private ActionBar mActionBar;
    private String mServerAddress = null;

    private OnDataChangedInterface mInterface = () -> {
        if (mCurrentFragment == null) {
            return;
        }

        if (mCurrentFragment.isVisible()){
            mCurrentFragment.onDataChanged();
        }
    };

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = item -> {
        switch (item.getItemId()) {
            case R.id.navigation_home:
                showHomeFragment();
                return true;
            case R.id.navigation_requests:
                showRequestsFragment();
                return true;
            case R.id.navigation_alerts:
                showAlertsFragment();
                return true;
            case R.id.navigation_profile:
                showProfileFragment();
                return true;
            default:
                return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Provide a callback for the NetworkManager
        NetworkManager.getInstance().setOnDataChangedInterface(mInterface);

        mNavigationView = findViewById(R.id.navigation);
        mNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        initializeActionBar();

        //If a server address has not yet been provided, show the AddressFragment
        if (mServerAddress == null){
            showAddressFragment();
        } else {
            showHomeFragment();
        }
    }

    @Override
    protected void onDestroy() {
        NetworkManager.getInstance().setOnDataChangedInterface(null);
        super.onDestroy();
    }

    private void initializeActionBar() {
        mActionBar = getSupportActionBar();
        if (mActionBar == null) {
            return;
        }
        mActionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        mActionBar.setCustomView(R.layout.actionbar_logo);
        ImageView shield = mActionBar.getCustomView().findViewById(R.id.img_actionbar_logo);
        shield.setColorFilter(getColor(R.color.colorAccent), PorterDuff.Mode.SRC_IN);
        mActionBar.show();
    }

    private void showAddressFragment() {
        mNavigationView.setVisibility(View.INVISIBLE);
        FragmentManager manager = getFragmentManager();
        AddressFragment fragment = new AddressFragment();
        manager.beginTransaction()
                .replace(R.id.root_activity_home_inner, fragment, fragment.getClass().getName()).commit();
    }

    public void showHomeFragment() {
        mNavigationView.setVisibility(View.VISIBLE);
        FragmentManager manager = getFragmentManager();
        HomeFragment fragment = new HomeFragment();
        manager.beginTransaction()
                .replace(R.id.root_activity_home_inner, fragment, fragment.getClass().getName()).commit();
        mCurrentFragment = fragment;
    }

    private void showRequestsFragment() {
        FragmentManager manager = getFragmentManager();
        RequestsFragment fragment = new RequestsFragment();
        manager.beginTransaction()
                .replace(R.id.root_activity_home_inner, fragment, fragment.getClass().getName()).commit();
        mCurrentFragment = fragment;
    }

    private void showAlertsFragment() {
        FragmentManager manager = getFragmentManager();
        AlertsFragment fragment = new AlertsFragment();
        manager.beginTransaction()
                .replace(R.id.root_activity_home_inner, fragment, fragment.getClass().getName()).commit();
        mCurrentFragment = fragment;
    }

    private void showProfileFragment() {
        FragmentManager manager = getFragmentManager();
        ProfileFragment fragment = new ProfileFragment();
        manager.beginTransaction()
                .replace(R.id.root_activity_home_inner, fragment, fragment.getClass().getName()).commit();
        mCurrentFragment = fragment;
    }

    public void setSelectedTab(int itemId){
        mNavigationView.setSelectedItemId(itemId);
    }

    public void setServerAddress(String address){
        mServerAddress = address;
        ApiAdapter.getInstance().setServerAddress(address);
    }
}
