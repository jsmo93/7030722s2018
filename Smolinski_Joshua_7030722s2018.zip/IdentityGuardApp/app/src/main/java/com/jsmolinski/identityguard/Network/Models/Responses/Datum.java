package com.jsmolinski.identityguard.Network.Models.Responses;


import com.google.gson.annotations.SerializedName;

public class Datum {
    @SerializedName("ssn")
    public String ssn;

    @SerializedName("passport_number")
    public String passportNumber;

    @SerializedName("dob")
    public String dob;

    @SerializedName("license_number")
    public String licenseNumber;

    @SerializedName("license_state")
    public String licenseState;

    @SerializedName("license_issue")
    public String licenseIssue;

    @SerializedName("license_expiration")
    public String licenseExpir;

    @SerializedName("email")
    public String email;

    @SerializedName("phone_number")
    public String phoneNumber;

    @SerializedName("address")
    public String address;

    @SerializedName("first_name")
    public String firstName;

    @SerializedName("middle_name")
    public String middleName;

    @SerializedName("last_name")
    public String lastName;

    @SerializedName("occupation")
    public String occupation;

    @SerializedName("employer")
    public String employer;

    @SerializedName("guid")
    public String guid;

    public Datum(
            String ssn,
            String dob,
            String passportNumber,
            String licenseNumber,
            String licenseState,
            String licenseIssue,
            String licenseExpir,
            String email,
            String phoneNumber,
            String address,
            String firstName,
            String middleName,
            String lastName,
            String occupation,
            String employer,
            String guid){
        this.ssn = ssn;
        this.dob = dob;
        this.passportNumber = passportNumber;
        this.licenseNumber = licenseNumber;
        this.licenseState = licenseState;
        this.licenseIssue = licenseIssue;
        this.licenseExpir = licenseExpir;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.occupation = occupation;
        this.employer = employer;
        this.guid = guid;
    }
}
