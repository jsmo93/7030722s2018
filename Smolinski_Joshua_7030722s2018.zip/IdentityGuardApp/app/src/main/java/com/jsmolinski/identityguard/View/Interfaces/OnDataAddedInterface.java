package com.jsmolinski.identityguard.View.Interfaces;

import com.jsmolinski.identityguard.Data.Models.Datum;

public interface OnDataAddedInterface {
    void onDataAdded(Datum datum);
}
