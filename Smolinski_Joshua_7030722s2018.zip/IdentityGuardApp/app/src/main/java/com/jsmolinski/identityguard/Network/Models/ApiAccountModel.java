package com.jsmolinski.identityguard.Network.Models;

import com.jsmolinski.identityguard.Network.Models.Responses.AccessRequest;
import com.jsmolinski.identityguard.Network.Models.Responses.Alert;
import com.jsmolinski.identityguard.Network.Models.Responses.Datum;

import java.util.List;

public class ApiAccountModel {
    private List<Datum> datums;
    private List<AccessRequest> accessRequests;
    private List<Alert> alerts;

    public ApiAccountModel(List<Datum> datums, List<AccessRequest> accessRequests, List<Alert> alerts){
        this.datums = datums;
        this.accessRequests = accessRequests;
        this.alerts = alerts;
    }

    public List<Datum> getDatums(){
        return datums;
    }

    public List<AccessRequest> getAccessRequests(){
        return accessRequests;
    }

    public List<Alert> getAlerts(){
        return alerts;
    }

    public void setDatums(List<Datum> datums){
        this.datums = datums;
    }

    public void setAlerts(List<Alert> alerts){
        this.alerts = alerts;
    }

    public void setAccessRequests(List<AccessRequest> accessRequests){
        this.accessRequests = accessRequests;
    }
}
