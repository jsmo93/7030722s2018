package com.jsmolinski.identityguard.Data.Models;

public class Transaction {

}
