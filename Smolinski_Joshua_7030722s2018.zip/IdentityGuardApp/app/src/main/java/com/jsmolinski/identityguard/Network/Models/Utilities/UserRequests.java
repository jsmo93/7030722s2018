package com.jsmolinski.identityguard.Network.Models.Utilities;

import com.jsmolinski.identityguard.Network.Models.Requests.UserRequest;

/**
 * This class stores the UserRequest templates. Requests can be created by filling in the required
 * parameters.
 */
public class UserRequests {
    public static UserRequest getSequenceRequest(){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "post",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
    }

    public static UserRequest getIndexAlertRequest(String sequenceNumber){
        return getIndexRequest(sequenceNumber);
    }

    public static UserRequest getGetAlertRequest(String sequenceNumber, String alertId){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "get",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                null,
                null,
                null,
                alertId,
                null,
                null,
                null);
    }

    public static UserRequest getIndexAccessRequestRequest(String sequenceNumber){
        return getIndexRequest(sequenceNumber);
    }

    public static UserRequest getGetAccessRequestRequest(String sequenceNumber, String requestId){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "get",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                null,
                null,
                null,
                null,
                requestId,
                null,
                null);
    }

    public static UserRequest getPutAccessRequestRequest(String sequenceNumber, String datumKey, String requestClient, String status){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "put",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                null,
                datumKey,
                null,
                null,
                null,
                requestClient,
                status);
    }

    public static UserRequest getIndexDatumRequest(String sequenceNumber){
        return getIndexRequest(sequenceNumber);
    }

    public static UserRequest getGetDatumRequest(String sequenceNumber, String datumId){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "get",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                datumId,
                null,
                null,
                null,
                null,
                null,
                null);
    }

    public static UserRequest getPostDatumRequest(String sequenceNumber, String key, String value){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "post",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                null,
                key,
                value,
                null,
                null,
                null,
                null);
    }

    public static UserRequest getIndexRequest(String sequenceNumber){
        return new UserRequest(
                ClientSecrets.getInstance().getClientId(),
                "index",
                sequenceNumber,
                ClientSecrets.getInstance().getEmail(),
                ClientSecrets.getInstance().getPassword(),
                null,
                null,
                null,
                null,
                null,
                null,
                null);
    }
}
