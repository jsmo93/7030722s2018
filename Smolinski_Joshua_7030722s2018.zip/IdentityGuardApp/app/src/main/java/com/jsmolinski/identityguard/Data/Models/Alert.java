package com.jsmolinski.identityguard.Data.Models;

public class Alert {
    private final String mClientName;
    private final AlertStatus mAlertStatus;

    public Alert(String clientName, AlertStatus alertStatus){
        mClientName = clientName;
        mAlertStatus = alertStatus;
    }

    public String getClientName(){
        return mClientName;
    }

    public AlertStatus getStatus(){
        return mAlertStatus;
    }

    public enum AlertStatus {
        ACTIVE(0),
        INACTIVE(1);

        int value;

        AlertStatus(int value){
            this.value = value;
        }

        public int getValue(){
            return value;
        }
    }
}
