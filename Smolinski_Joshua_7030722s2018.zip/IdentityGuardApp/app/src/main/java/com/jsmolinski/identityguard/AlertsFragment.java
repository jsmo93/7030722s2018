package com.jsmolinski.identityguard;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jsmolinski.identityguard.Data.Models.Alert;
import com.jsmolinski.identityguard.Network.NetworkManager;
import com.jsmolinski.identityguard.View.Adapters.AlertListAdapter;
import com.jsmolinski.identityguard.View.Interfaces.OnReviewExposureInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class AlertsFragment extends BaseFragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;

    private OnReviewExposureInterface mInterface = () -> {
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setSelectedTab(R.id.navigation_requests);
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_alerts, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
    }

    public void initializeViews(){
        initializeViews(getActivity().findViewById(R.id.layout_alerts_root));
    }

    private void initializeViews(View view) {
        mRecyclerView = view.findViewById(R.id.recyclerview_alerts);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        //Get the current list of Alerts
        List<Alert> alertList = NetworkManager.getInstance().getAlerts();
        //Create ModelViews for the alerts
        List<AlertListAdapter.AlertModelView> alertModelViews = getAlertModelViewList(alertList);
        //Hand the ModelViews off to the adapter
        AlertListAdapter alertListAdapter = new AlertListAdapter(alertModelViews, getActivity(), mInterface);
        mRecyclerView.setAdapter(alertListAdapter);
    }

    public List<AlertListAdapter.AlertModelView> getAlertModelViewList(List<Alert> alerts){
        List<AlertListAdapter.AlertModelView> alertModelViews = new ArrayList<>();

        //Pull out all of the alerts, organize by client id
        Map<String, List<Alert>> alertMap = new HashMap<>();
        for (Alert a : alerts){
            List<Alert> alts = alertMap.get(a.getClientName());
            if (alts == null){
                alts = new ArrayList<>();
            }
            alts.add(a);
            alertMap.put(a.getClientName(), alts);
        }

        //Iterate through the client ids and build ModelViews for the alerts
        for(Iterator<String> iter = alertMap.keySet().iterator(); iter.hasNext();){
            String client = iter.next();
            alertModelViews.add(new AlertListAdapter.AlertModelView(
                    AlertListAdapter.ViewType.CLIENT_HEADER,
                    client,
                    null,
                    null,
                    getDrawableForClient(client)));

            List<Alert> alts = alertMap.get(client);
            if (alts != null){
                for (Alert a : alts){
                    alertModelViews.add(new AlertListAdapter.AlertModelView(
                            AlertListAdapter.ViewType.ITEM,
                            getString(R.string.alert_text),
                            a.getStatus(),
                            null,
                            null
                    ));
                }
            }
        }
        return alertModelViews;
    }

    public Integer getDrawableForClient(String client){
        if (client.equalsIgnoreCase("FreeCreditReport")){
            return R.drawable.credit;
        } else if (client.equalsIgnoreCase("WickedPizza")){
            return R.drawable.pizza;
        } else if (client.equalsIgnoreCase("CityElectric")){
            return R.drawable.power;
        } else {
            return null;
        }
    }

    @Override
    public void onDataChanged() {
        initializeViews();
    }
}
