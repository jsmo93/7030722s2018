package com.jsmolinski.identityguard.Network.Models.Utilities;

import android.util.Base64;

import com.google.gson.Gson;
import com.jsmolinski.identityguard.Network.Models.Responses.EncryptedResponse;
import com.jsmolinski.identityguard.Network.Models.Responses.ResponseWrapper;
import com.jsmolinski.identityguard.Network.Models.Responses.UserResponse;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * This class takes an EncryptedResponse and decrypts it to create a UserResponse.
 */
public class ResponseDecryptor {
    public static UserResponse decryptResponse(EncryptedResponse encryptedResponse){
        //Verify signature
        if (!isValidSignature(encryptedResponse.key, encryptedResponse.signature)){
            return null;
        }

        //Decrypt key
        String key = decryptKey(encryptedResponse.key);

        //Decrypt encryptedRequest
        return createResponseObject(encryptedResponse.response, key, encryptedResponse.secret);
    }

    private static UserResponse createResponseObject(String request, String key, String secret){
        try {
            Cipher cipher = Cipher.getInstance("AES_256/CBC/PKCS5Padding");
            byte[] ivBytes = Base64.decode(secret, Base64.DEFAULT);
            byte[] keyBytes = Base64.decode(key, Base64.DEFAULT);
            Key symKey = new SecretKeySpec(keyBytes, "AES");
            cipher.init(Cipher.DECRYPT_MODE, symKey, new IvParameterSpec(ivBytes));

            byte[] encryptedBytes = Base64.decode(request, Base64.DEFAULT);
            byte[] plainBytes = cipher.doFinal(encryptedBytes);
            String plainString = new String(plainBytes);

            Gson gson = new Gson();
            return gson.fromJson(plainString, UserResponse.class);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | InvalidAlgorithmParameterException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return null;
        }
    }

    private static String decryptKey(String key){
        try {
            Cipher cipher = Cipher.getInstance("RSA/NONE/PKCS1Padding");
            PrivateKey clientKey = ClientSecrets.getInstance().getPrivateKey();
            cipher.init(Cipher.DECRYPT_MODE, clientKey);
            byte[] keyBytes = Base64.decode(key, Base64.DEFAULT);
            byte[] decryptedBytes = cipher.doFinal(keyBytes);
            return new String(decryptedBytes);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return null;
        }
    }

    private static boolean isValidSignature(String key, String signature){
        try {
            Cipher cipher = Cipher.getInstance("RSA/NONE/PKCS1Padding");
            PublicKey serverKey = ServerSecrets.getInstance().getPublicKey();
            cipher.init(Cipher.DECRYPT_MODE, serverKey);

            byte[] signatureBytes = Base64.decode(signature, Base64.DEFAULT);
            byte[] decryptedBytes = cipher.doFinal(signatureBytes);
            String testString = new String(decryptedBytes);
            String keyString = key.substring(0, 128);
            return (testString.equals(keyString));
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return false;
        }
    }
}
