package com.jsmolinski.identityguard.View.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.jsmolinski.identityguard.Data.Models.Alert;
import com.jsmolinski.identityguard.R;
import com.jsmolinski.identityguard.View.Interfaces.OnReviewExposureInterface;

import java.util.List;

public class AlertListAdapter extends RecyclerView.Adapter<AlertListAdapter.ViewHolder> {
    private List<AlertModelView> mAlertModelViewList;
    private Context mContext;
    private OnReviewExposureInterface mInterface;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public View mView;

        public ViewHolder(View v) {
            super(v);
            mView = v;
        }
    }

    public AlertListAdapter(List<AlertModelView> alertModelViewList, Context context, OnReviewExposureInterface exposureInterface) {
        mContext = context;
        mAlertModelViewList = alertModelViewList;
        mInterface = exposureInterface;
    }

    @Override
    public AlertListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                          int viewType) {
        View view;
        if (viewType == ViewType.CLIENT_HEADER.getValue()) {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_header_client, parent, false);
        } else {
            view = LayoutInflater.from(mContext)
                    .inflate(R.layout.view_list_item_alert, parent, false);
        }

        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        AlertModelView alertModelView = mAlertModelViewList.get(position);
        TextView textView;
        if (alertModelView.getViewType() == ViewType.CLIENT_HEADER) {
            textView = holder.mView.findViewById(R.id.text_view_header);
            textView.setText(alertModelView.getPrimaryText());
            if (alertModelView.getDrawableId() != null) {
                ImageView img = holder.mView.findViewById(R.id.img_client);
                img.setImageDrawable(mContext.getDrawable(alertModelView.getDrawableId()));
            }
        } else if (alertModelView.getViewType() == ViewType.ITEM) {
            textView = holder.mView.findViewById(R.id.text_view_item);
            textView.setText(alertModelView.getPrimaryText());
            Button btn = holder.mView.findViewById(R.id.btn_review_exposure);
            btn.setOnClickListener(v -> mInterface.onReviewExposure());
        } else {
            textView = holder.mView.findViewById(R.id.text_view_item);
            textView.setText(alertModelView.getPrimaryText());
        }
    }

    @Override
    public int getItemCount() {
        return mAlertModelViewList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return mAlertModelViewList.get(position).getViewType().getValue();
    }

    public static class AlertModelView {
        ViewType mViewType;
        String mPrimaryText;
        Alert.AlertStatus mStatus;
        String mCreatedOn;
        Integer mDrawableId;

        public AlertModelView(ViewType viewType, String primaryText, Alert.AlertStatus status, String createdOn, Integer drawableId) {
            mViewType = viewType;
            mPrimaryText = primaryText;
            mStatus = status;
            mCreatedOn = createdOn;
            mDrawableId = drawableId;
        }

        public ViewType getViewType() {
            return mViewType;
        }

        public String getPrimaryText() {
            return mPrimaryText;
        }

        public Alert.AlertStatus getStatus() {
            return mStatus;
        }

        public String getSensativity(){
            return mCreatedOn;
        }

        public Integer getDrawableId() {
            return mDrawableId;
        }
    }

    public enum ViewType {
        CLIENT_HEADER(0),
        ITEM(1);

        int value;

        ViewType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
    

}
