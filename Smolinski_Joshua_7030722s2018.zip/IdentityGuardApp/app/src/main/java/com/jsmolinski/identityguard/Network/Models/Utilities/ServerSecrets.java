package com.jsmolinski.identityguard.Network.Models.Utilities;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

/**
 * In an actual deployment of this system, these properties would be securely stored using the
 * Android Keystore
 */
public final class ServerSecrets {
    private static final ServerSecrets mSecrets = new ServerSecrets();
    private RSAPublicKey publicKey;

    private ServerSecrets(){
        BigInteger mod = new BigInteger("28910845665814012663687407240532388491463939352053565110608366558842634334161389860719487456763744507113428990463800683982208468152082255528811939214505033229863864273969970148316630041592411004753930745931914473987400380212378367252193756349413107016221935657566540842047606832374967912796560282581847523864404975802061662458352630739521997881942293767157098324668996233610149678567631460587622508871975316024382944928642923264703758990807674394486792867495989014564616720968756676559829322351606520404102694130737063978485505313006292564019307084342579490395663704162311917757631319206484599650269322212282537803767");
        BigInteger pubExp = new BigInteger("65537");
        publicKey = createPublicKey(mod, pubExp);
    }

    public static ServerSecrets getInstance(){
        return mSecrets;
    }

    public RSAPublicKey createPublicKey(BigInteger mod, BigInteger pubExp){
        try {
            RSAPublicKeySpec pub = new RSAPublicKeySpec(mod, pubExp);

            KeyFactory keyFactory;
            keyFactory = KeyFactory.getInstance("RSA");

            return (RSAPublicKey)keyFactory.generatePublic(pub);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e){
            return null;
        }
    }

    public RSAPublicKey getPublicKey() {
        return publicKey;
    }
}
