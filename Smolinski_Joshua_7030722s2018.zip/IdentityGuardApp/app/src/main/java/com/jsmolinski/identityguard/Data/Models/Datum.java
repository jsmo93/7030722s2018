package com.jsmolinski.identityguard.Data.Models;

public class Datum {
    private final DatumKey mKey;
    private String mValue;
    private final Sensativity mSensativity;

    public Datum(DatumKey key, String value){
        mKey = key;
        mValue = value;
        mSensativity = getSensativityForDatum(key);
    }

    public DatumKey getKey(){
        return mKey;
    }

    public String getValue(){
        return mValue;
    }

    public void setValue(String value){
        mValue = value;
    }

    public Sensativity getSensativity(){
        return mSensativity;
    }

    public enum DatumKey {
        SSN(0),
        PASSPORT_NUMBER(1),
        DOB(2),
        LICENSE_NUMBER(3),
        LICENSE_STATE(4),
        LICENSE_ISSUE(5),
        LICENSE_EXPIRATION(6),
        EMAIL(7),
        PHONE_NUMBER(8),
        ADDRESS(9),
        FIRST_NAME(10),
        MIDDLE_NAME(11),
        LAST_NAME(12),
        OCCUPATION(13),
        EMPLOYER(14);

        int value;

        DatumKey(int value){
            this.value = value;
        }

        public int getValue(){
            return value;
        }
    }

    public enum Sensativity {
        LOW(0),
        MEDIUM(1),
        HIGH(2);

        int value;

        Sensativity(int value){
            this.value = value;
        }

        public int getValue(){
            return value;
        }
    }

    public static Sensativity getSensativityForDatum(DatumKey key){
        if (key == null){
            return null;
        }

        switch (key){
            case SSN:
            case PASSPORT_NUMBER:
            case LICENSE_NUMBER:
                return Sensativity.HIGH;
            case DOB:
            case LICENSE_STATE:
            case LICENSE_ISSUE:
            case LICENSE_EXPIRATION:
                return Sensativity.MEDIUM;
            case EMAIL:
            case ADDRESS:
            case PHONE_NUMBER:
            case FIRST_NAME:
            case MIDDLE_NAME:
            case LAST_NAME:
            case OCCUPATION:
            case EMPLOYER:
                return Sensativity.LOW;
            default:
                return null;
        }
    }

    public static String getDisplayName(DatumKey datumKey){
        if (datumKey == null){
            return null;
        }

        switch (datumKey){
            case SSN:
                return "Social Security Number";
            case PASSPORT_NUMBER:
                return "Passport Number";
            case DOB:
                return "Birthday";
            case LICENSE_NUMBER:
                return "License Number";
            case LICENSE_STATE:
                return "License State";
            case LICENSE_ISSUE:
                return "License Issue";
            case LICENSE_EXPIRATION:
                return "License Expiration";
            case EMAIL:
                return "Email";
            case ADDRESS:
                return "Address";
            case PHONE_NUMBER:
                return "Phone Number";
            case FIRST_NAME:
                return "First Name";
            case MIDDLE_NAME:
                return "Middle Name";
            case LAST_NAME:
                return "Last Name";
            case OCCUPATION:
                return "Occupation";
            case EMPLOYER:
                return "Employer";
            default:
                return null;
        }
    }
}
