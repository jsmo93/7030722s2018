package com.jsmolinski.identityguard.Network;

import android.util.Pair;

import com.jsmolinski.identityguard.Data.Models.AppAccountModel;
import com.jsmolinski.identityguard.Network.Models.ApiAccountModel;
import com.jsmolinski.identityguard.Network.Models.Requests.EncryptedRequest;
import com.jsmolinski.identityguard.Network.Models.Requests.RequestWrapper;
import com.jsmolinski.identityguard.Network.Models.Responses.AccessRequest;
import com.jsmolinski.identityguard.Network.Models.Responses.Alert;
import com.jsmolinski.identityguard.Network.Models.Responses.Datum;
import com.jsmolinski.identityguard.Network.Models.Responses.EncryptedResponse;
import com.jsmolinski.identityguard.Network.Models.Responses.UserResponse;
import com.jsmolinski.identityguard.Network.Models.Utilities.RequestEncryptor;
import com.jsmolinski.identityguard.Network.Models.Utilities.ResponseDecryptor;
import com.jsmolinski.identityguard.Network.Models.Utilities.UserRequests;
import com.jsmolinski.identityguard.Network.Models.Requests.UserRequest;
import com.jsmolinski.identityguard.Utilities.AccountModelConverter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * The ApiAdapter is the single point of contact for Retrofit calls. Requests are made by the
 * NetworkManager with key/value pairs. The key/value pairs are used to create UserRequests.
 * UserRequests are encrypted with the RequestEncryptor and returned as EncryptedRequests. The
 * EncryptedRequests are then wrapped in a RequestWrapper and handed off to Retrofit. Retrofit
 * returns a ResponseWrapper containing an EncryptedResponse. EncryptedResponses are decrypted with
 * the ResponseDecryptor and returned as UserResponses. These are converted to key/value pairs or
 * a complete AppAccountModel in the case of a full sync.
 *
 * RxJava is used to chain Retrofit calls together. The NetworkManager can subscribe to an operation
 * and will be notified with the result when it is complete.
 */
public class ApiAdapter {
    private static String mBaseUrl;
    private IdentityGuardApiEndpointInterface mApiInterface;
    private Retrofit mRetrofit;
    private boolean mockMode;
    private String lastSequence;

    private static final ApiAdapter mInstance = new ApiAdapter();

    private ApiAdapter() {
        mockMode = true;
    }

    public static ApiAdapter getInstance(){
        return mInstance;
    }

    public void setServerAddress(String address) {
        if (address == null){
            mockMode = true;
        } else {
            mBaseUrl = "http://" + address + ":3000/api/v1/";
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(mBaseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .build();
            mApiInterface = mRetrofit.create(IdentityGuardApiEndpointInterface.class);
            mockMode = false;
        }
    }

    public boolean isMockMode(){
        return mockMode;
    }

    public Observable<AppAccountModel> getAppAccount(){
        return getApiAccount()
                .flatMap(apiAccountModel -> Observable.just(AccountModelConverter.toAppModel(apiAccountModel)));
    }

    private Observable<ApiAccountModel> getApiAccount(){
        return getAllData()
                .flatMap(data -> Observable.just(new ApiAccountModel(data, null, null))).flatMap(apiAccountModel -> getAllAccessRequests()
                        .flatMap(accessRequests -> {
                            apiAccountModel.setAccessRequests(accessRequests);
                            return Observable.just(apiAccountModel);
                        })).flatMap(apiAccountModel -> getAllAlerts()
                                .flatMap(alerts -> {
                                    apiAccountModel.setAlerts(alerts);
                                    return Observable.just(apiAccountModel);
                        }));
    }

    public Observable<Map<String, String>> updateAccessRequest(Map<String, String> params){
        return getSequenceNumber()
                .flatMap(sequenceNumber -> {
                    UserRequest putAccessRequestRequest = UserRequests.getPutAccessRequestRequest(
                            sequenceNumber,
                            params.get(AccountModelConverter.KEY_DATAM_KEY),
                            params.get(AccountModelConverter.KEY_REQUEST_CLIENT),
                            params.get(AccountModelConverter.KEY_STATUS));
                    EncryptedRequest encryptedPutAccessRequestRequest = RequestEncryptor.encryptRequest(putAccessRequestRequest);
                    RequestWrapper putAccessRequestRequestWrapper = new RequestWrapper(encryptedPutAccessRequestRequest);
                    return mApiInterface.accessRequestRequest(putAccessRequestRequestWrapper);
                }).flatMap(putAccessRequestResponseWrapper -> {
                    EncryptedResponse encryptedPutAccessRequestResponse = putAccessRequestResponseWrapper.encryptedResponse;
                    UserResponse putAccessRequestResponse = ResponseDecryptor.decryptResponse(encryptedPutAccessRequestResponse);
                    lastSequence = putAccessRequestResponse.sequenceNumber.guid;
                    return Observable.just(new Pair<>(lastSequence, putAccessRequestResponse.accessRequest.guid));
                }).flatMap(pair -> {
                    UserRequest getAccessRequestRequest = UserRequests.getGetAccessRequestRequest(pair.first, pair.second);
                    EncryptedRequest encryptedGetAccessRequestRequest = RequestEncryptor.encryptRequest(getAccessRequestRequest);
                    RequestWrapper getAccessRequestRequestWrapper = new RequestWrapper(encryptedGetAccessRequestRequest);
                    return mApiInterface.accessRequestRequest(getAccessRequestRequestWrapper)
                            .flatMap(getAccessRequestResponseWrapper -> {
                                EncryptedResponse encryptedGetAccessRequestResponse = getAccessRequestResponseWrapper.encryptedResponse;
                                UserResponse getAccessRequestResponse = ResponseDecryptor.decryptResponse(encryptedGetAccessRequestResponse);
                                lastSequence = getAccessRequestResponse.sequenceNumber.guid;
                                Map<String, String> map = new HashMap<>();
                                map.put(AccountModelConverter.KEY_REQUEST_CLIENT, getAccessRequestResponse.accessRequest.requestClient);
                                map.put(AccountModelConverter.KEY_DATAM_KEY, getAccessRequestResponse.accessRequest.datumKey);
                                map.put(AccountModelConverter.KEY_NAME, getAccessRequestResponse.accessRequest.name);
                                map.put(AccountModelConverter.KEY_STATUS, getAccessRequestResponse.accessRequest.status);
                                return Observable.just(map);
                            });
                });
    }

    public Observable<Map<String, String>> addDatum(Map<String, String> params){
        return getSequenceNumber()
                .flatMap(sequenceNumber -> {
                    UserRequest postDatumRequest = UserRequests.getPostDatumRequest(sequenceNumber,
                            params.get(AccountModelConverter.KEY_DATAM_KEY),
                            params.get(AccountModelConverter.KEY_DATAM_VALUE));
                    EncryptedRequest encryptedPostDatumRequest = RequestEncryptor.encryptRequest(postDatumRequest);
                    RequestWrapper postDatumRequestWrapper = new RequestWrapper(encryptedPostDatumRequest);
                    return mApiInterface.datumRequest(postDatumRequestWrapper);
                }).flatMap(postDatumResponseWrapper -> {
                    EncryptedResponse encryptedPostDatumResponse = postDatumResponseWrapper.encryptedResponse;
                    UserResponse postDatumResponse = ResponseDecryptor.decryptResponse(encryptedPostDatumResponse);
                    lastSequence = postDatumResponse.sequenceNumber.guid;
                    return Observable.just(new Pair<>(lastSequence, postDatumResponse.datum.guid));
                }).flatMap(pair -> {
                    UserRequest getDatumRequest = UserRequests.getGetDatumRequest(pair.first, pair.second);
                    EncryptedRequest encryptedGetDatumRequest = RequestEncryptor.encryptRequest(getDatumRequest);
                    RequestWrapper getDatumRequestWrapper = new RequestWrapper(encryptedGetDatumRequest);
                    return mApiInterface.datumRequest(getDatumRequestWrapper)
                            .flatMap(getDatumResponseWrapper -> {
                                EncryptedResponse encryptedGetDatumResponse = getDatumResponseWrapper.encryptedResponse;
                                UserResponse getDatumResponse = ResponseDecryptor.decryptResponse(encryptedGetDatumResponse);
                                lastSequence = getDatumResponse.sequenceNumber.guid;
                                Map<String, String> map = new HashMap<>();
                                Pair<String, String> datumInfo = AccountModelConverter.getDatumStringInfo(getDatumResponse.datum);
                                map.put(AccountModelConverter.KEY_DATAM_KEY, datumInfo.first);
                                map.put(AccountModelConverter.KEY_DATAM_VALUE, datumInfo.second);
                                return Observable.just(map);
                            });
                });
    }

    private Observable<String> getSequenceNumber(){
        if (lastSequence == null){
            UserRequest getSequenceRequest = UserRequests.getSequenceRequest();
            EncryptedRequest encryptedGetSequenceRequest = RequestEncryptor.encryptRequest(getSequenceRequest);
            RequestWrapper getSequenceRequestWrapper = new RequestWrapper(encryptedGetSequenceRequest);
            return mApiInterface.sequenceNumberRequest(getSequenceRequestWrapper)
                    .flatMap(getSequenceResponseWrapper -> {
                        EncryptedResponse encryptedGetSequenceResponse = getSequenceResponseWrapper.encryptedResponse;
                        UserResponse getSequenceResponse = ResponseDecryptor.decryptResponse(encryptedGetSequenceResponse);
                        lastSequence = getSequenceResponse.sequenceNumber.guid;
                        return Observable.just(lastSequence);
                    });
        }
        return Observable.just(lastSequence);
    }

    private Observable<List<Datum>> getAllData(){
        List<Datum> datums = new ArrayList<>();
        return getSequenceNumber()
                .flatMap(sequenceNumber -> {
                    UserRequest indexDatumRequest = UserRequests.getIndexDatumRequest(lastSequence);
                    EncryptedRequest encryptedIndexDatumRequest = RequestEncryptor.encryptRequest(indexDatumRequest);
                    RequestWrapper indexDatumRequestWrapper = new RequestWrapper(encryptedIndexDatumRequest);
                    return mApiInterface.datumRequest(indexDatumRequestWrapper);
                })
                .flatMap(indexDatumResponseWrapper -> {
                    EncryptedResponse encryptedIndexDatumResponse = indexDatumResponseWrapper.encryptedResponse;
                    UserResponse indexDatumResponse = ResponseDecryptor.decryptResponse(encryptedIndexDatumResponse);
                    lastSequence = indexDatumResponse.sequenceNumber.guid;
                    return Observable.fromIterable(indexDatumResponse.datums);
                }).concatMap(guid -> getSequenceNumber()
                        .flatMap(sequenceNumber -> {
                            UserRequest getDatumRequest = UserRequests.getGetDatumRequest(sequenceNumber, guid);
                            EncryptedRequest encryptedGetDatumRequest = RequestEncryptor.encryptRequest(getDatumRequest);
                            RequestWrapper getDatumRequestWrapper = new RequestWrapper(encryptedGetDatumRequest);
                            return mApiInterface.datumRequest(getDatumRequestWrapper)
                                    .flatMap(getDatumResponseWrapper -> {
                                        EncryptedResponse encryptedGetDatumResponse = getDatumResponseWrapper.encryptedResponse;
                                        UserResponse getDatumResponse = ResponseDecryptor.decryptResponse(encryptedGetDatumResponse);
                                        lastSequence = getDatumResponse.sequenceNumber.guid;
                                        return Observable.just(getDatumResponse.datum);
                                    });
                        })).collect(() -> datums, (l, d) -> l.add(d))
                .flatMapObservable(Observable::just);
    }

    private Observable<List<Alert>> getAllAlerts(){
        List<Alert> alerts = new ArrayList<>();
        return getSequenceNumber()
                .flatMap(sequenceNumber -> {
                    UserRequest indexAlertRequest = UserRequests.getIndexAlertRequest(sequenceNumber);
                    EncryptedRequest encryptedIndexAlertRequest = RequestEncryptor.encryptRequest(indexAlertRequest);
                    RequestWrapper indexAlertRequestWrapper = new RequestWrapper(encryptedIndexAlertRequest);
                    return mApiInterface.alertRequest(indexAlertRequestWrapper);
                })
                .flatMap(indexAlertResponseWrapper -> {
                    EncryptedResponse encryptedIndexAlertResponse = indexAlertResponseWrapper.encryptedResponse;
                    UserResponse indexAlertResponse = ResponseDecryptor.decryptResponse(encryptedIndexAlertResponse);
                    lastSequence = indexAlertResponse.sequenceNumber.guid;
                    return Observable.fromIterable(indexAlertResponse.alerts);
                }).concatMap(guid -> getSequenceNumber()
                        .flatMap(sequenceNumber -> {
                            UserRequest getAlertRequest = UserRequests.getGetAlertRequest(sequenceNumber, guid);
                            EncryptedRequest encryptedGetAlertRequest = RequestEncryptor.encryptRequest(getAlertRequest);
                            RequestWrapper getAlertRequestWrapper = new RequestWrapper(encryptedGetAlertRequest);
                            return mApiInterface.alertRequest(getAlertRequestWrapper)
                                    .flatMap(getAlertResponseWrapper -> {
                                        EncryptedResponse encryptedGetAlertResponse = getAlertResponseWrapper.encryptedResponse;
                                        UserResponse getAlertResponse = ResponseDecryptor.decryptResponse(encryptedGetAlertResponse);
                                        lastSequence = getAlertResponse.sequenceNumber.guid;
                                        return Observable.just(getAlertResponse.alert);
                                    });
                        })).collect(() -> alerts, (l, a) -> l.add(a))
                .flatMapObservable(Observable::just);
    }

    private Observable<List<AccessRequest>> getAllAccessRequests(){
        List<AccessRequest> accessRequests = new ArrayList<>();
        return getSequenceNumber()
                .flatMap(sequenceNumber -> {
                    UserRequest indexAccessRequestRequest = UserRequests.getIndexAccessRequestRequest(sequenceNumber);
                    EncryptedRequest encryptedIndexAccessRequestRequest = RequestEncryptor.encryptRequest(indexAccessRequestRequest);
                    RequestWrapper indexAccessRequestRequestWrapper = new RequestWrapper(encryptedIndexAccessRequestRequest);
                    return mApiInterface.accessRequestRequest(indexAccessRequestRequestWrapper);
                })
                .flatMap(indexAccessRequestResponseWrapper -> {
                    EncryptedResponse encryptedIndexAccessReqestResponse = indexAccessRequestResponseWrapper.encryptedResponse;
                    UserResponse indexAccessRequestResponse = ResponseDecryptor.decryptResponse(encryptedIndexAccessReqestResponse);
                    lastSequence = indexAccessRequestResponse.sequenceNumber.guid;
                    return Observable.fromIterable(indexAccessRequestResponse.accessRequests);
                }).concatMap(guid -> getSequenceNumber()
                        .flatMap(sequenceNumber -> {
                            UserRequest getAccessRequestRequest = UserRequests.getGetAccessRequestRequest(sequenceNumber, guid);
                            EncryptedRequest encryptedGetAccessRequestRequest = RequestEncryptor.encryptRequest(getAccessRequestRequest);
                            RequestWrapper getAccessRequestRequestWrapper = new RequestWrapper(encryptedGetAccessRequestRequest);
                            return mApiInterface.accessRequestRequest(getAccessRequestRequestWrapper)
                                    .flatMap(getAccessRequestResponseWrapper -> {
                                        EncryptedResponse encryptedGetAccessRequestResponse = getAccessRequestResponseWrapper.encryptedResponse;
                                        UserResponse getAccessRequestResponse = ResponseDecryptor.decryptResponse(encryptedGetAccessRequestResponse);
                                        lastSequence = getAccessRequestResponse.sequenceNumber.guid;
                                        return Observable.just(getAccessRequestResponse.accessRequest);
                                    });
                        })).collect(() -> accessRequests, (l, d) -> l.add(d))
                .flatMapObservable(Observable::just);
    }
}
