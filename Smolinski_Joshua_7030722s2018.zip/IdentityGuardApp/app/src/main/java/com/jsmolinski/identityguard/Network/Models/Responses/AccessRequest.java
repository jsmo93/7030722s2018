package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

public class AccessRequest {
    @SerializedName("name")
    public String name;

    @SerializedName("datum_key")
    public String datumKey;

    @SerializedName("status")
    public String status;

    @SerializedName("guid")
    public String guid;

    @SerializedName("request_client")
    public String requestClient;

    public AccessRequest(String name, String datumKey, String status, String guid, String requestClient){
        this.name = name;
        this.datumKey = datumKey;
        this.status = status;
        this.guid = guid;
        this.requestClient = requestClient;
    }
}
