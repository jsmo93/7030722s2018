package com.jsmolinski.identityguard;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.Network.NetworkManager;
import com.jsmolinski.identityguard.View.Adapters.DatumListAdapter;
import com.jsmolinski.identityguard.View.Interfaces.OnDataAddedInterface;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends BaseFragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private AlertDialog mConfirmationDialog;
    private AlertDialog mLoadingDialog;

    private OnDataAddedInterface mInterface = new OnDataAddedInterface() {
        @Override
        public void onDataAdded(Datum datum) {
            showConfirmationDialog(datum);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
    }

    public void initializeViews(){
        initializeViews(getActivity().findViewById(R.id.layout_profile_root));
    }

    private void initializeViews(View view) {
        mRecyclerView = view.findViewById(R.id.recyclerview_profile);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        //Get the current list of Datums
        List<Datum> datumList = NetworkManager.getInstance().getDatums();
        //Create ModelViews for the datums
        List<DatumListAdapter.DatumModelView> datumModelViews = getDatumModelViewList(datumList);
        //Hand the ModelViews off to the adapter
        DatumListAdapter datumListAdapter = new DatumListAdapter(datumModelViews, getActivity(), mInterface);
        mRecyclerView.setAdapter(datumListAdapter);
    }

    public List<DatumListAdapter.DatumModelView> getDatumModelViewList(List<Datum> datums){
        List<DatumListAdapter.DatumModelView> datumModelViews = new ArrayList<>();
        List<DatumListAdapter.DatumModelView> displayViews = new ArrayList<>();
        List<DatumListAdapter.DatumModelView> entryViews = new ArrayList<>();

        //Iterate through the possible datum keys
        Datum.DatumKey[] keys = Datum.DatumKey.values();
        for (Datum.DatumKey k : keys){
            String value = getDatumValue(datums, k);
            //If there is no value for the key, show an entry item
            //Else, show a display item
            if (value == null) {
                entryViews.add(new DatumListAdapter.DatumModelView(
                        DatumListAdapter.ViewType.ITEM_ENTRY,
                        k,
                        null));
            } else {
                displayViews.add(new DatumListAdapter.DatumModelView(
                        DatumListAdapter.ViewType.ITEM_DISPLAY,
                        k,
                        value));
            }
        }

        datumModelViews.addAll(displayViews);
        datumModelViews.addAll(entryViews);

        return datumModelViews;
    }

    public String getDatumValue(List<Datum> datums, Datum.DatumKey key){
        for (Datum d : datums){
            if (d.getKey() == key){
                return d.getValue();
            }
        }
        return null;
    }

    private void showConfirmationDialog(Datum datum){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you set this value? It cannot be changed once it has been created.");
        builder.setPositiveButton("SET", (dialog, which) -> {
            showLoadingDialog();
            dialog.dismiss();
            mConfirmationDialog = null;
            NetworkManager.getInstance().addDatum(datum);
        });
        builder.setNegativeButton("CANCEL", (dialog, which) -> {
            dialog.dismiss();
            mConfirmationDialog = null;
        });
        mConfirmationDialog = builder.create();
        mConfirmationDialog.show();
    }

    private void showLoadingDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setTitle("Syncing Your Data...");
        builder.setView(inflater.inflate(R.layout.view_loading, null));
        builder.setCancelable(false);
        mLoadingDialog = builder.create();
        mLoadingDialog.show();
    }

    public void dismissLoadingDialog(){
        if (mLoadingDialog != null) {
            mLoadingDialog.dismiss();
            mLoadingDialog = null;
        }
    }

    @Override
    public void onDataChanged() {
        initializeViews();
        dismissLoadingDialog();
    }
}
