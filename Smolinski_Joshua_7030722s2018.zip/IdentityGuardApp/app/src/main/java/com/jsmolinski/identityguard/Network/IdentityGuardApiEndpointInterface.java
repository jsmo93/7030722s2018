package com.jsmolinski.identityguard.Network;

import com.jsmolinski.identityguard.Network.Models.Requests.RequestWrapper;
import com.jsmolinski.identityguard.Network.Models.Responses.ResponseWrapper;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * This interface is used by Retrofit to create the appropriate network calls.
 */
public interface IdentityGuardApiEndpointInterface {
    @POST("sequence_numbers")
    Observable<ResponseWrapper> sequenceNumberRequest(@Body RequestWrapper requestWrapper);

    @POST("data")
    Observable<ResponseWrapper> datumRequest(@Body RequestWrapper requestWrapper);

    @POST("access_requests")
    Observable<ResponseWrapper> accessRequestRequest(@Body RequestWrapper requestWrapper);

    @POST("alerts")
    Observable<ResponseWrapper> alertRequest(@Body RequestWrapper requestWrapper);
}
