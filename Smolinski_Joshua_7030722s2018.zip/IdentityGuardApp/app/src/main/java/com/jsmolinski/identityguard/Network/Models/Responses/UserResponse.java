package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class UserResponse {
    @SerializedName("datum")
    public Datum datum;

    @SerializedName("access_requests")
    public List<String> accessRequests;

    @SerializedName("access_request")
    public AccessRequest accessRequest;

    @SerializedName("datums")
    public List<String> datums;

    @SerializedName("alert")
    public Alert alert;

    @SerializedName("alerts")
    public List<String> alerts;

    @SerializedName("sequence_number")
    public SequenceNumber sequenceNumber;

    public UserResponse(
            Datum datum,
            List<String> datums,
            AccessRequest accessRequest,
            List<String> accessRequests,
            Alert alert,
            List<String> alerts,
            SequenceNumber sequenceNumber){
        this.datum = datum;
        this.datums = datums;
        this.accessRequest = accessRequest;
        this.accessRequests = accessRequests;
        this.alert = alert;
        this.alerts = alerts;
        this.sequenceNumber = sequenceNumber;
    }
}
