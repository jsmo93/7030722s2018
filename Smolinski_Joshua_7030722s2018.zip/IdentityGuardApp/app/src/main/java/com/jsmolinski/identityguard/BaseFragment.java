package com.jsmolinski.identityguard;

import android.app.Fragment;

import com.jsmolinski.identityguard.View.Interfaces.OnDataChangedInterface;

public abstract class BaseFragment extends Fragment implements OnDataChangedInterface{
    //Intentionally blank
}
