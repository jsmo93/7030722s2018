package com.jsmolinski.identityguard.Network.Models.Requests;

import com.google.gson.annotations.SerializedName;

public class EncryptedRequest {
    @SerializedName("client")
    public String client;

    @SerializedName("key")
    public String key;

    @SerializedName("secret")
    public String secret;

    @SerializedName("encrypted_request")
    public String encryptedRequest;

    @SerializedName("signature")
    public String signature;

    public EncryptedRequest(String client, String key, String secret, String encryptedRequest, String signature){
        this.client = client;
        this.key = key;
        this.secret = secret;
        this.encryptedRequest = encryptedRequest;
        this.signature = signature;
    }
}
