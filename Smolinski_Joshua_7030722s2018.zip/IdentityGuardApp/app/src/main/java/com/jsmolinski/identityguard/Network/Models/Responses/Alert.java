package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

public class Alert {
    @SerializedName("name")
    public String name;

    @SerializedName("status")
    public String status;

    public Alert(String name, String status){
        this.name = name;
        this.status = status;
    }
}
