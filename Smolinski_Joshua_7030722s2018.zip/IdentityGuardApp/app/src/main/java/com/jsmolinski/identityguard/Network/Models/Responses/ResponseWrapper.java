package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseWrapper {
    @SerializedName("response")
    public EncryptedResponse encryptedResponse;

    public ResponseWrapper(EncryptedResponse encryptedResponse){
        this.encryptedResponse = encryptedResponse;
    }
}
