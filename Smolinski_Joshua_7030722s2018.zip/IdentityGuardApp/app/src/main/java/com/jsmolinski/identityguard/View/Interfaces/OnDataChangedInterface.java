package com.jsmolinski.identityguard.View.Interfaces;

public interface OnDataChangedInterface {
    void onDataChanged();
}
