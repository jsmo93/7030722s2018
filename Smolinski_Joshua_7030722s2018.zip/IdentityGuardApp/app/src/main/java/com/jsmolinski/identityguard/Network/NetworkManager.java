package com.jsmolinski.identityguard.Network;

import com.jsmolinski.identityguard.Data.Models.AccessRequest;
import com.jsmolinski.identityguard.Data.Models.Alert;
import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.Utilities.AccountModelConverter;
import com.jsmolinski.identityguard.View.Interfaces.OnDataChangedInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * The NetworkManager is the App's single point of contact for all network calls. It provides and
 * receives App models which are converted to key/value pairs and sent to the ApiAdapter. The
 * NetworkManager can operate in standard or mock mode, depending on if the App is communicating
 * with a real server.
 */
public class NetworkManager {
    private static final NetworkManager mManager = new NetworkManager();
    private OnDataChangedInterface mInterface;
    private boolean syncRequired;

    private List<AccessRequest> mAccessRequests;
    private List<Alert> mAlerts;
    private List<Datum> mDatums;

    private NetworkManager(){
        syncRequired = true;
        mAccessRequests = new ArrayList<>();
        mAlerts = new ArrayList<>();
        mDatums = new ArrayList<>();
    }

    public static NetworkManager getInstance(){
        return mManager;
    }

    public void setOnDataChangedInterface(OnDataChangedInterface dataChangedInterface){
        mInterface = dataChangedInterface;
    }

    public boolean isSyncRequired(){
        return syncRequired;
    }

    public List<AccessRequest> getAccessRequests(){
        return mAccessRequests;
    }

    public List<Alert> getAlerts(){
        return mAlerts;
    }

    public List<Datum> getDatums(){
        return mDatums;
    }

    public void fetchAccount(){
        if (ApiAdapter.getInstance().isMockMode()){
            fetchMockAccount();
        } else {
            fetchApiAccount();
        }
    }

    private void fetchApiAccount(){
        ApiAdapter.getInstance().getAppAccount()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(appAccountModel -> {
                    syncRequired = false;
                    mDatums = appAccountModel.getDatums();
                    mAccessRequests = appAccountModel.getAccessRequests();
                    mAlerts = appAccountModel.getAlerts();
                    mInterface.onDataChanged();
                }, Throwable::printStackTrace);
    }

    private void fetchMockAccount(){
        syncRequired = false;
        mDatums = fetchMockDatums();
        mAccessRequests = fetchMockAccessRequests();
        mAlerts = fetchMockAlerts();
        mInterface.onDataChanged();
    }

    public void updateAccessRequest(AccessRequest accessRequest){
        if (ApiAdapter.getInstance().isMockMode()){
            updateMockAccessRequest(accessRequest);
        } else {
            updateApiAccessRequest(accessRequest);
        }
    }

    private void updateApiAccessRequest(AccessRequest accessRequest){
        Map<String, String> map = new HashMap<>();
        map.put(AccountModelConverter.KEY_REQUEST_CLIENT, accessRequest.getRequestClient());
        map.put(AccountModelConverter.KEY_DATAM_KEY, AccountModelConverter.getDatumKeyString(accessRequest.getDatumKey()));
        map.put(AccountModelConverter.KEY_STATUS, AccountModelConverter.getAccessRequestStatusString(accessRequest.getStatus()));
        ApiAdapter.getInstance().updateAccessRequest(map)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(params -> {
                    Datum.DatumKey key = AccountModelConverter.getDatumKey(params.get(AccountModelConverter.KEY_DATAM_KEY));
                    AccessRequest.RequestStatus status
                            = AccountModelConverter.getAccessRequestStatus(params.get(AccountModelConverter.KEY_STATUS));
                    AccessRequest modifiedAccessRequest = new AccessRequest(
                            params.get(AccountModelConverter.KEY_NAME),
                            params.get(AccountModelConverter.KEY_REQUEST_CLIENT),
                            key,
                            status);
                    updateRequest(modifiedAccessRequest);
                    mInterface.onDataChanged();
                }, Throwable::printStackTrace);
    }

    private void updateMockAccessRequest(AccessRequest accessRequest){
        updateRequest(accessRequest);
        mInterface.onDataChanged();
    }

    public void addDatum(Datum datum){
        if (ApiAdapter.getInstance().isMockMode()){
            addMockDatum(datum);
        } else {
            addApiDatum(datum);
        }
    }

    private void addApiDatum(Datum datum){
        Map<String, String> map = new HashMap<>();
        map.put(AccountModelConverter.KEY_DATAM_KEY, AccountModelConverter.getDatumKeyString(datum.getKey()));
        map.put(AccountModelConverter.KEY_DATAM_VALUE, datum.getValue());
        ApiAdapter.getInstance().addDatum(map)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(params -> {
                    Datum.DatumKey key = AccountModelConverter.getDatumKey(params.get(AccountModelConverter.KEY_DATAM_KEY));
                    Datum modifiedDatum = new Datum(
                            key,
                            params.get(AccountModelConverter.KEY_DATAM_VALUE));
                    mDatums.add(modifiedDatum);
                    mInterface.onDataChanged();
                }, Throwable::printStackTrace);
    }

    private void addMockDatum(Datum datum){
        mDatums.add(datum);
        mInterface.onDataChanged();
    }

    private void updateRequest(AccessRequest request){
        for (AccessRequest r : mAccessRequests){
            if (r.getClientName().equalsIgnoreCase(request.getClientName()) && r.getDatumKey() == request.getDatumKey()){
                r.setStatus(request.getStatus());
                break;
            }
        }
    }

    public List<AccessRequest> fetchMockAccessRequests(){
        List<AccessRequest> requests = new ArrayList<>();
        requests.add(new AccessRequest("FreeCreditReport", "51f24638-1176-4d57-9c92-608e80c4066d", Datum.DatumKey.SSN, AccessRequest.RequestStatus.PENDING));
        requests.add(new AccessRequest("FreeCreditReport", "51f24638-1176-4d57-9c92-608e80c4066d", Datum.DatumKey.DOB, AccessRequest.RequestStatus.PENDING));
        requests.add(new AccessRequest("FreeCreditReport", "51f24638-1176-4d57-9c92-608e80c4066d", Datum.DatumKey.EMAIL, AccessRequest.RequestStatus.PENDING));

        requests.add(new AccessRequest("CityElectric", "31ff6ae7-b37f-4aba-9897-574af2d1a6ed", Datum.DatumKey.ADDRESS, AccessRequest.RequestStatus.APPROVED));
        requests.add(new AccessRequest("CityElectric", "31ff6ae7-b37f-4aba-9897-574af2d1a6ed", Datum.DatumKey.LICENSE_NUMBER, AccessRequest.RequestStatus.APPROVED));
        requests.add(new AccessRequest("CityElectric", "31ff6ae7-b37f-4aba-9897-574af2d1a6ed", Datum.DatumKey.LICENSE_STATE, AccessRequest.RequestStatus.APPROVED));

        requests.add(new AccessRequest("WickedPizza", "608c8cca-59dd-40f2-b22f-c32cbfe0533b", Datum.DatumKey.DOB, AccessRequest.RequestStatus.DENIED));
        requests.add(new AccessRequest("WickedPizza", "608c8cca-59dd-40f2-b22f-c32cbfe0533b", Datum.DatumKey.PHONE_NUMBER, AccessRequest.RequestStatus.APPROVED));

        return requests;
    }

    public List<Alert> fetchMockAlerts(){
        List<Alert> alerts = new ArrayList<>();
        alerts.add(new Alert("CityElectric", Alert.AlertStatus.ACTIVE));

        return alerts;
    }

    public List<Datum> fetchMockDatums(){
        List<Datum> datums = new ArrayList<>();
        datums.add(new Datum(Datum.DatumKey.SSN, "111-11-1111"));
        datums.add(new Datum(Datum.DatumKey.DOB, "11-11-1999"));
        datums.add(new Datum(Datum.DatumKey.PHONE_NUMBER, "111-111-1111"));

        return datums;
    }
}
