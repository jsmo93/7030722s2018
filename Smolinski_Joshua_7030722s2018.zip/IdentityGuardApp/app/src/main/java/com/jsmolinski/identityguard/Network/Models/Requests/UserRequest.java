package com.jsmolinski.identityguard.Network.Models.Requests;

import com.google.gson.annotations.SerializedName;

public class UserRequest {
    @SerializedName("client_id")
    String clientId;

    @SerializedName("operation")
    String operation;

    @SerializedName("sequence_number")
    String sequenceNumber;

    @SerializedName("user_email")
    String userEmail;

    @SerializedName("user_password")
    String userPassword;

    @SerializedName("datum_id")
    String datumId;

    @SerializedName("datum_key")
    String datumKey;

    @SerializedName("datum_value")
    String datumValue;

    @SerializedName("alert_id")
    String alertId;

    @SerializedName("request_id")
    String requestId;

    @SerializedName("request_client")
    String requestClient;

    @SerializedName("status")
    String status;

    public UserRequest(
            String clientId,
            String operation,
            String sequenceNumber,
            String userEmail,
            String userPassword,
            String datumId,
            String datumKey,
            String datumValue,
            String alertId,
            String requestId,
            String requestClient,
            String status){
        this.clientId = clientId;
        this.operation = operation;
        this.sequenceNumber = sequenceNumber;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.datumId = datumId;
        this.datumKey = datumKey;
        this.datumValue = datumValue;
        this.alertId = alertId;
        this.requestId = requestId;
        this.requestClient = requestClient;
        this.status = status;
    }
}
