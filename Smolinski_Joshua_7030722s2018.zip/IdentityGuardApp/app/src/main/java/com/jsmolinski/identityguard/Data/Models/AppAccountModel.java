package com.jsmolinski.identityguard.Data.Models;

import java.util.List;

public class AppAccountModel {
    private final List<Datum> datums;
    private final List<AccessRequest> accessRequests;
    private final List<Alert> alerts;

    public AppAccountModel(List<Datum> datums, List<AccessRequest> accessRequests, List<Alert> alerts){
        this.datums = datums;
        this.accessRequests = accessRequests;
        this.alerts = alerts;
    }

    public List<Datum> getDatums(){
        return datums;
    }

    public List<AccessRequest> getAccessRequests(){
        return accessRequests;
    }

    public List<Alert> getAlerts(){
        return alerts;
    }
}
