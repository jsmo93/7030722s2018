package com.jsmolinski.identityguard;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.Data.Models.AccessRequest;
import com.jsmolinski.identityguard.Network.NetworkManager;
import com.jsmolinski.identityguard.View.Adapters.RequestListAdapter;
import com.jsmolinski.identityguard.View.Interfaces.OnRequestActionInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RequestsFragment extends BaseFragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private AlertDialog mConfirmationDialog;
    private AlertDialog mLoadingDialog;

    private OnRequestActionInterface mInterface = new OnRequestActionInterface() {
        @Override
        public void onRequestApproved(String client, Datum.DatumKey key) {
            AccessRequest request = findRequest(client, key);
            request.setStatus(AccessRequest.RequestStatus.APPROVED);
            showApprovalDialog(request);
        }

        @Override
        public void onRequestDenied(String client, Datum.DatumKey key) {
            AccessRequest request = findRequest(client, key);
            request.setStatus(AccessRequest.RequestStatus.DENIED);
            showDenialDialog(request);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_requests, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
    }

    public void initializeViews(){
        initializeViews(getActivity().findViewById(R.id.layout_requests_root));
    }

    private void initializeViews(View view) {
        mRecyclerView = view.findViewById(R.id.recyclerview_requests);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        //Get the current list of AccessRequests
        List<AccessRequest> requestList = NetworkManager.getInstance().getAccessRequests();
        //Create ModelViews for the requests
        List<RequestListAdapter.RequestModelView> requestModelViews = getRequestViewList(requestList);
        //Hand the ModelViews off to the adapter
        RequestListAdapter requestListAdapter = new RequestListAdapter(requestModelViews, getActivity(), mInterface);
        mRecyclerView.setAdapter(requestListAdapter);
    }

    private List<RequestListAdapter.RequestModelView> getRequestViewList(List<AccessRequest> requests) {
        List<RequestListAdapter.RequestModelView> requestModelViews = new ArrayList<>();
        //Get the pending requests first
        requestModelViews.addAll(getRequestViewListByStatus(requests, true));
        //Get the past requests next
        requestModelViews.addAll(getRequestViewListByStatus(requests, false));
        return requestModelViews;
    }

    public List<RequestListAdapter.RequestModelView> getRequestViewListByStatus(List<AccessRequest> requests, boolean pending){
        List<RequestListAdapter.RequestModelView> requestModelViews = new ArrayList<>();
        String headerText = pending ? "Pending Requests:" : "Past Requests:";
        requestModelViews.add(new RequestListAdapter.RequestModelView(headerText));

        //Pull out all of the requests, organize by client id
        Map<String, List<AccessRequest>> requestMap = new HashMap<>();
        for (AccessRequest r : requests){
            if (pending && r.getStatus() == AccessRequest.RequestStatus.PENDING) {
                List<AccessRequest> reqs = requestMap.get(r.getClientName());
                if (reqs == null){
                    reqs = new ArrayList<>();
                }
                reqs.add(r);
                requestMap.put(r.getClientName(), reqs);
            } else if (!pending && r.getStatus() != AccessRequest.RequestStatus.PENDING){
                List<AccessRequest> reqs = requestMap.get(r.getClientName());
                if (reqs == null){
                    reqs = new ArrayList<>();
                }
                reqs.add(r);
                requestMap.put(r.getClientName(), reqs);
            }
        }

        //Iterate through the client ids and build ModelViews for the requests
        for(Iterator<String> iter = requestMap.keySet().iterator(); iter.hasNext();){
            String client = iter.next();
            requestModelViews.add(new RequestListAdapter.RequestModelView(
                    client,
                    getDrawableForClient(client)));

            List<AccessRequest> reqs = requestMap.get(client);
            if (reqs != null){
                for (AccessRequest r : reqs){
                    requestModelViews.add(new RequestListAdapter.RequestModelView(
                            r.getClientName(),
                            r.getDatumKey(),
                            r.getStatus(),
                            Datum.getSensativityForDatum(r.getDatumKey())));
                }
            }
        }
        return requestModelViews;
    }

    public Integer getDrawableForClient(String client){
        if (client.equalsIgnoreCase("FreeCreditReport")){
            return R.drawable.credit;
        } else if (client.equalsIgnoreCase("WickedPizza")){
            return R.drawable.pizza;
        } else if (client.equalsIgnoreCase("CityElectric")){
            return R.drawable.power;
        } else {
            return null;
        }
    }

    private void showApprovalDialog(AccessRequest request){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Approval");
        builder.setMessage("Are you sure you want to approve this data encryptedRequest?");
        builder.setPositiveButton("CONFIRM", (dialog, which) -> {
            showLoadingDialog();
            dialog.dismiss();
            mConfirmationDialog = null;
            NetworkManager.getInstance().updateAccessRequest(request);
        });
        builder.setNegativeButton("CANCEL", (dialog, which) -> {
            dialog.dismiss();
            mConfirmationDialog = null;
        });
        mConfirmationDialog = builder.create();
        mConfirmationDialog.show();
    }

    private void showDenialDialog(AccessRequest request){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Denial");
        builder.setMessage("Are you sure you want to deny this data encryptedRequest?");
        builder.setPositiveButton("CONFIRM", (dialog, which) -> {
            showLoadingDialog();
            dialog.dismiss();
            mConfirmationDialog = null;
            NetworkManager.getInstance().updateAccessRequest(request);
        });
        builder.setNegativeButton("CANCEL", (dialog, which) -> {
            dialog.dismiss();
            mConfirmationDialog = null;
        });
        mConfirmationDialog = builder.create();
        mConfirmationDialog.show();
    }

    public AccessRequest findRequest(String client, Datum.DatumKey key) {
        List<AccessRequest> requests = NetworkManager.getInstance().getAccessRequests();
        for (AccessRequest r : requests){
            if (r.getClientName().equalsIgnoreCase(client) && r.getDatumKey() == key) {
                return r;
            }
        }
        return null;
    }

    private void showLoadingDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setTitle("Syncing Your Data...");
        builder.setView(inflater.inflate(R.layout.view_loading, null));
        builder.setCancelable(false);
        mLoadingDialog = builder.create();
        mLoadingDialog.show();
    }

    public void dismissLoadingDialog(){
        if (mLoadingDialog != null) {
            mLoadingDialog.dismiss();
            mLoadingDialog = null;
        }
    }

    @Override
    public void onDataChanged() {
        initializeViews();
        dismissLoadingDialog();
    }
}
