package com.jsmolinski.identityguard.Utilities;

import android.util.Pair;

import com.jsmolinski.identityguard.Data.Models.AccessRequest;
import com.jsmolinski.identityguard.Data.Models.Alert;
import com.jsmolinski.identityguard.Data.Models.AppAccountModel;
import com.jsmolinski.identityguard.Data.Models.Datum;
import com.jsmolinski.identityguard.Network.Models.ApiAccountModel;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a utility class which helps convert between the App and Api Models. While the models
 * share data, they may not be identical. Separating them allows easier integration with Retrofit
 * and cleaner App code.
 */
public class AccountModelConverter {
    public static final String KEY_REQUEST_CLIENT = "request_client";
    public static final String KEY_DATAM_KEY = "datum_key";
    public static final String KEY_DATAM_VALUE = "datum_value";
    public static final String KEY_NAME = "name";
    public static final String KEY_STATUS = "status";

    public static ApiAccountModel toApiModel(AppAccountModel appAccountModel) {
        //TODO
        return null;
    }

    public static AppAccountModel toAppModel(ApiAccountModel apiAccountModel) {
        List<Datum> datums = new ArrayList<>();
        for (com.jsmolinski.identityguard.Network.Models.Responses.Datum d : apiAccountModel.getDatums()) {
            Pair<Datum.DatumKey, String> datumInfo = getDatumInfo(d);
            if (datumInfo == null){
                continue;
            }
            Datum datum = new Datum(datumInfo.first, datumInfo.second);
            datums.add(datum);
        }

        List<AccessRequest> accessRequests = new ArrayList<>();
        for (com.jsmolinski.identityguard.Network.Models.Responses.AccessRequest a : apiAccountModel.getAccessRequests()){
            Datum.DatumKey key = getDatumKey(a.datumKey);
            AccessRequest.RequestStatus status = getAccessRequestStatus(a.status);
            AccessRequest accessRequest = new AccessRequest(a.name, a.requestClient, key, status);
            accessRequests.add(accessRequest);
        }

        List<Alert> alerts = new ArrayList<>();
        for (com.jsmolinski.identityguard.Network.Models.Responses.Alert a : apiAccountModel.getAlerts()){
            Alert.AlertStatus status = getAlertStatus(a.status);
            Alert alert = new Alert(a.name, status);
            alerts.add(alert);
        }

        return new AppAccountModel(datums, accessRequests, alerts);
    }

    public static Pair<Datum.DatumKey, String> getDatumInfo(com.jsmolinski.identityguard.Network.Models.Responses.Datum datum) {
        if (datum.ssn != null) {
            return new Pair<>(Datum.DatumKey.SSN, datum.ssn);
        } else if (datum.passportNumber != null) {
            return new Pair<>(Datum.DatumKey.PASSPORT_NUMBER, datum.passportNumber);
        } else if (datum.dob != null) {
            return new Pair<>(Datum.DatumKey.DOB, datum.dob);
        } else if (datum.licenseNumber != null) {
            return new Pair<>(Datum.DatumKey.LICENSE_NUMBER, datum.licenseNumber);
        } else if (datum.licenseState != null) {
            return new Pair<>(Datum.DatumKey.LICENSE_STATE, datum.licenseState);
        } else if (datum.licenseIssue != null) {
            return new Pair<>(Datum.DatumKey.LICENSE_ISSUE, datum.licenseIssue);
        } else if (datum.licenseExpir != null) {
            return new Pair<>(Datum.DatumKey.LICENSE_EXPIRATION, datum.licenseExpir);
        } else if (datum.email != null) {
            return new Pair<>(Datum.DatumKey.EMAIL, datum.email);
        } else if (datum.phoneNumber != null) {
            return new Pair<>(Datum.DatumKey.PHONE_NUMBER, datum.phoneNumber);
        } else if (datum.address != null) {
            return new Pair<>(Datum.DatumKey.ADDRESS, datum.address);
        } else if (datum.firstName != null) {
            return new Pair<>(Datum.DatumKey.FIRST_NAME, datum.firstName);
        } else if (datum.middleName != null) {
            return new Pair<>(Datum.DatumKey.MIDDLE_NAME, datum.middleName);
        } else if (datum.lastName != null) {
            return new Pair<>(Datum.DatumKey.LAST_NAME, datum.lastName);
        } else if (datum.occupation != null) {
            return new Pair<>(Datum.DatumKey.OCCUPATION, datum.occupation);
        } else if (datum.employer != null) {
            return new Pair<>(Datum.DatumKey.EMPLOYER, datum.employer);
        }
        return null;
    }

    public static Pair<String, String> getDatumStringInfo(com.jsmolinski.identityguard.Network.Models.Responses.Datum datum) {
        if (datum.ssn != null) {
            return new Pair<>("ssn", datum.ssn);
        } else if (datum.passportNumber != null) {
            return new Pair<>("passport_number", datum.passportNumber);
        } else if (datum.dob != null) {
            return new Pair<>("dob", datum.dob);
        } else if (datum.licenseNumber != null) {
            return new Pair<>("license_number", datum.licenseNumber);
        } else if (datum.licenseState != null) {
            return new Pair<>("license_state", datum.licenseState);
        } else if (datum.licenseIssue != null) {
            return new Pair<>("license_issue", datum.licenseIssue);
        } else if (datum.licenseExpir != null) {
            return new Pair<>("license_expiration", datum.licenseExpir);
        } else if (datum.email != null) {
            return new Pair<>("email", datum.email);
        } else if (datum.phoneNumber != null) {
            return new Pair<>("phone_number", datum.phoneNumber);
        } else if (datum.address != null) {
            return new Pair<>("address", datum.address);
        } else if (datum.firstName != null) {
            return new Pair<>("first_name", datum.firstName);
        } else if (datum.middleName != null) {
            return new Pair<>("middle_name", datum.middleName);
        } else if (datum.lastName != null) {
            return new Pair<>("last_name", datum.lastName);
        } else if (datum.occupation != null) {
            return new Pair<>("occupation", datum.occupation);
        } else if (datum.employer != null) {
            return new Pair<>("employer", datum.employer);
        }
        return null;
    }

    public static Datum.DatumKey getDatumKey(String key){
        switch (key){
            case "ssn":
                return Datum.DatumKey.SSN;
            case "passport_number":
                return Datum.DatumKey.PASSPORT_NUMBER;
            case "dob":
                return Datum.DatumKey.DOB;
            case "license_number":
                return Datum.DatumKey.LICENSE_NUMBER;
            case "license_state":
                return Datum.DatumKey.LICENSE_STATE;
            case "license_issue":
                return Datum.DatumKey.LICENSE_ISSUE;
            case "license_expiration":
                return Datum.DatumKey.LICENSE_EXPIRATION;
            case "email":
                return Datum.DatumKey.EMAIL;
            case "phone_number":
                return Datum.DatumKey.PHONE_NUMBER;
            case "address":
                return Datum.DatumKey.ADDRESS;
            case "first_name":
                return Datum.DatumKey.FIRST_NAME;
            case "middle_name":
                return Datum.DatumKey.MIDDLE_NAME;
            case "last_name":
                return Datum.DatumKey.LAST_NAME;
            case "occupation":
                return Datum.DatumKey.OCCUPATION;
            case "employer":
                return Datum.DatumKey.EMPLOYER;
            default:
                return null;
        }
    }

    public static AccessRequest.RequestStatus getAccessRequestStatus(String accessRequestStatus){
        switch (accessRequestStatus){
            case "pending":
                return AccessRequest.RequestStatus.PENDING;
            case "approved":
                return AccessRequest.RequestStatus.APPROVED;
            case "denied":
                return AccessRequest.RequestStatus.DENIED;
            default:
                return null;
        }
    }

    public static Alert.AlertStatus getAlertStatus(String alertStatus){
        switch (alertStatus){
            case "active":
                return Alert.AlertStatus.ACTIVE;
            case "inactive":
                return Alert.AlertStatus.INACTIVE;
            default:
                return null;
        }
    }
    
    public static String getDatumKeyString(Datum.DatumKey key){
        if (key == null){
            return null;
        }
        
        switch (key) {
            case SSN:
                return "ssn";
            case PASSPORT_NUMBER:
                return "passport_number";
            case DOB:
                return "dob";
            case LICENSE_NUMBER:
                return "license_number";
            case LICENSE_STATE:
                return "license_state";
            case LICENSE_ISSUE:
                return "license_issue";
            case LICENSE_EXPIRATION:
                return "license_expiration";
            case EMAIL:
                return "email";
            case PHONE_NUMBER:
                return "phone_number";
            case ADDRESS:
                return "address";
            case FIRST_NAME:
                return "first_name";
            case MIDDLE_NAME:
                return "middle_name";
            case LAST_NAME:
                return "last_name";
            case OCCUPATION:
                return "occupation";
            case EMPLOYER:
                return "employer";
            default:
                return null;
        }
    }
    
    public static String getAccessRequestStatusString(AccessRequest.RequestStatus accessRequestStatus){
        switch (accessRequestStatus){
            case PENDING:
                return "pending";
            case APPROVED:
                return "approved";
            case DENIED:
                return "denied";
            default:
                return null;
        }
    }
}
