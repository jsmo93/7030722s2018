package com.jsmolinski.identityguard.Data.Models;

public class AccessRequest {
    private final String mClientName;
    private final String mRequestClient;
    private final Datum.DatumKey mDatumKey;
    private RequestStatus mStatus;

    public AccessRequest(String clientName, String requestClient, Datum.DatumKey datumKey, RequestStatus status){
        mClientName = clientName;
        mRequestClient = requestClient;
        mDatumKey = datumKey;
        mStatus = status;
    }

    public String getClientName(){
        return mClientName;
    }

    public String getRequestClient(){
        return mRequestClient;
    }

    public Datum.DatumKey getDatumKey(){
        return mDatumKey;
    }

    public RequestStatus getStatus(){
        return mStatus;
    }

    public void setStatus(RequestStatus status){
        mStatus = status;
    }

    public enum RequestStatus {
        PENDING(0),
        APPROVED(1),
        DENIED(2);

        int value;

        RequestStatus(int value){
            this.value = value;
        }

        public int getValue(){
            return value;
        }
    }
}
