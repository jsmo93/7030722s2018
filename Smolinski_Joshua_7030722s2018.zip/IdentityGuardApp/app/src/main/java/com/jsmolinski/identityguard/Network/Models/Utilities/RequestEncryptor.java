package com.jsmolinski.identityguard.Network.Models.Utilities;

import android.util.Base64;

import com.google.gson.Gson;
import com.jsmolinski.identityguard.Network.Models.Requests.EncryptedRequest;
import com.jsmolinski.identityguard.Network.Models.Requests.UserRequest;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * This class takes a UserRequest and encrypts it to create an EncryptedRequest
 */
public class RequestEncryptor {
    private static final String KEY_KEY = "key";
    private static final String IV_KEY = "iv";
    private static final String REQEUST_KEY = "encryptedRequest";

    public static EncryptedRequest encryptRequest(UserRequest request){
        Map<String, String> requestObject = createRequestObject(request);
        if (requestObject == null) {
            return null;
        }

        String clientId = ClientSecrets.getInstance().clientId;
        String req = requestObject.get(REQEUST_KEY);
        String secret = requestObject.get(IV_KEY);
        String encryptedKey = encryptKey(requestObject.get(KEY_KEY));
        String signature = signKey(encryptedKey);
        return new EncryptedRequest(
                clientId,
                encryptedKey,
                secret,
                req,
                signature);
    }

    private static Map<String, String> createRequestObject(UserRequest request){
        Map<String, String> requestMap = new HashMap<>();
        try {
            Cipher cipher = Cipher.getInstance("AES_256/CBC/PKCS5Padding");
            SecureRandom secureRandom = new SecureRandom();
            byte[] ivBytes = new byte[16];
            secureRandom.nextBytes(ivBytes);
            byte[] keyBytes = new byte[32];
            secureRandom.nextBytes(keyBytes);
            Key key = new SecretKeySpec(keyBytes, "AES");

            Gson gson = new Gson();
            String requestJson = gson.toJson(request);
            byte[] plainBytes = requestJson.getBytes("UTF8");
            cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(ivBytes));

            byte[] encryptedBytes = cipher.doFinal(plainBytes);
            String encryptedString = Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
            String keyString = Base64.encodeToString(keyBytes, Base64.DEFAULT);
            String ivString = Base64.encodeToString(ivBytes, Base64.DEFAULT);

            requestMap.put(REQEUST_KEY, encryptedString);
            requestMap.put(KEY_KEY, keyString);
            requestMap.put(IV_KEY, ivString);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | UnsupportedEncodingException
                | InvalidKeyException
                | InvalidAlgorithmParameterException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return null;
        }
        return requestMap;
    }

    private static String encryptKey(String key){
        try {
            Cipher cipher = Cipher.getInstance("RSA/NONE/PKCS1Padding");
            PublicKey serverKey = ServerSecrets.getInstance().getPublicKey();
            cipher.init(Cipher.ENCRYPT_MODE, serverKey);
            byte[] keyBytes = key.getBytes();
            byte[] encryptedBytes = cipher.doFinal(keyBytes);
            return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return null;
        }
    }

    private static String signKey(String key){
        try {
            Cipher cipher = Cipher.getInstance("RSA/NONE/PKCS1Padding");
            PrivateKey clientKey = ClientSecrets.getInstance().getPrivateKey();
            cipher.init(Cipher.ENCRYPT_MODE, clientKey);
            byte[] keyBytes = key.substring(0, 128).getBytes();
            byte[] encryptedBytes = cipher.doFinal(keyBytes);
            return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
        } catch (NoSuchAlgorithmException
                | NoSuchPaddingException
                | InvalidKeyException
                | IllegalBlockSizeException
                | BadPaddingException e){
            return null;
        }
    }
}
