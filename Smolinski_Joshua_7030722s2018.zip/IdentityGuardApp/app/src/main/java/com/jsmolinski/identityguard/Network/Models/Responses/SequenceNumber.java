package com.jsmolinski.identityguard.Network.Models.Responses;

import com.google.gson.annotations.SerializedName;

public class SequenceNumber {
    @SerializedName("guid")
    public String guid;

    public SequenceNumber(String guid){
        this.guid = guid;
    }
}
