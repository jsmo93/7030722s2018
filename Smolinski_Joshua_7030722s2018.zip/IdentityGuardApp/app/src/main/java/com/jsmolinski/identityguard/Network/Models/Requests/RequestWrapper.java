package com.jsmolinski.identityguard.Network.Models.Requests;

import com.google.gson.annotations.SerializedName;

public class RequestWrapper {
    @SerializedName("request")
    public EncryptedRequest encryptedRequest;

    public RequestWrapper(EncryptedRequest encryptedRequest){
        this.encryptedRequest = encryptedRequest;
    }
}
