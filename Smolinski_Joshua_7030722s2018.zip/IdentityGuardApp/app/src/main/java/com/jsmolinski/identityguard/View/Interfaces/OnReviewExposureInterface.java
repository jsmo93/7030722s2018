package com.jsmolinski.identityguard.View.Interfaces;

public interface OnReviewExposureInterface {
    void onReviewExposure();
}
