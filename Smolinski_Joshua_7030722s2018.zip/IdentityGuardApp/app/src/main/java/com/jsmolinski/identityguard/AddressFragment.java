package com.jsmolinski.identityguard;


import android.graphics.PorterDuff;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.jsmolinski.identityguard.Network.NetworkManager;


public class AddressFragment extends Fragment {
    private EditText mServerEditText;

    View.OnClickListener mSetListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            v.setOnClickListener(null);
            HomeActivity activity = (HomeActivity) getActivity();
            activity.setServerAddress(mServerEditText.getText().toString());
            activity.showHomeFragment();
        }
    };

    View.OnClickListener mMockListener = v -> {
        v.setOnClickListener(null);
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setServerAddress(null);
        activity.showHomeFragment();
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_address, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
    }

    private void initializeViews(View view){
        mServerEditText = view.findViewById(R.id.edit_address);
        mServerEditText.getBackground().setColorFilter(getResources().getColor(R.color.colorWhite, null), PorterDuff.Mode.SRC_IN);

        Button set = view.findViewById(R.id.btn_address_set);
        set.setOnClickListener(mSetListener);

        Button mock = view.findViewById(R.id.btn_mock_mode);
        mock.setOnClickListener(mMockListener);
    }
}
