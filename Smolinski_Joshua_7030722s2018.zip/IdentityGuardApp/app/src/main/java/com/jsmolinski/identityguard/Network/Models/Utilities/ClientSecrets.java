package com.jsmolinski.identityguard.Network.Models.Utilities;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

/**
 * In an actual deployment of this system, these properties would be securely stored using the
 * Android Keystore
 */
public final class ClientSecrets {
    private static final ClientSecrets mSecrets = new ClientSecrets();
    private RSAPrivateKey privateKey;
    private RSAPublicKey publicKey;

    final String clientId = "9bbd8e4f-0bd4-44ce-81af-0890e70a3673";
    final String email ="josh@mail.com";
    final String password = "pass1234";

    private ClientSecrets(){
        BigInteger mod = new BigInteger("20251937918292614482003104159333496306491358472272360018099818374150181584548385187042551948316996010355404170374907839014327618550765038560763851928246002886390422614569299385780440582695182325268714924371394570184923905367164635405137532428841581202545626677113434440572567805446289428746499872642866487144704949827888253755434025894144921150378606482674646950723562504677854090249400034032182073877492832255529703180066490756536091745089120094779962490710267641674023576676822733473527818456153435508092230772709764134766330040417139223079542514087744668890587875633248226902348562570730681321944682498708145021597");
        BigInteger pubExp = new BigInteger("65537");
        BigInteger prvExp = new BigInteger("8033780642992071521478198604366269999788857249525257728467263959155231713918685904034854594387067797995327793786820483065970206556339006553591690532531845873939579277867046789317788337411070846885515824706768940227164070551528849218956704885561185713471492475267330951767789459480791500504318227702965392568787702797196271545238958504349258498887986574619788020308446501064436279405811362543704148340110226504437690852471902385033662365820029286027841584439729725561486455288814510980879298839440358307575904345750370777342182444067076168467630500908987078091955646494256322537658956839451802229623999901514728691657");
        privateKey = createPrivateKey(mod, prvExp);
        publicKey = createPublicKey(mod, pubExp);
    }

    public static ClientSecrets getInstance(){
        return mSecrets;
    }

    public RSAPublicKey createPublicKey(BigInteger mod, BigInteger pubExp){
        try {
            RSAPublicKeySpec pub = new RSAPublicKeySpec(mod, pubExp);

            KeyFactory keyFactory;
            keyFactory = KeyFactory.getInstance("RSA");

            return (RSAPublicKey)keyFactory.generatePublic(pub);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e){
            return null;
        }
    }

    public RSAPrivateKey createPrivateKey(BigInteger mod, BigInteger prvExp){
        try {
            RSAPrivateKeySpec prv = new RSAPrivateKeySpec(mod, prvExp);

            KeyFactory keyFactory;
            keyFactory = KeyFactory.getInstance("RSA");

            return (RSAPrivateKey) keyFactory.generatePrivate(prv);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e){
            return null;
        }
    }

    public RSAPublicKey getPublicKey() {
        return publicKey;
    }

    public RSAPrivateKey getPrivateKey() {
        return privateKey;
    }

    public String getClientId(){
        return clientId;
    }

    public String getEmail(){
        return email;
    }

    public String getPassword(){
        return password;
    }
}
