package com.jsmolinski.identityguard;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jsmolinski.identityguard.Network.NetworkManager;

public class HomeFragment extends BaseFragment {
    private AlertDialog mLoadingDialog;

    View.OnClickListener requestCardListener = v -> {
        v.setOnClickListener(null);
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setSelectedTab(R.id.navigation_requests);
    };

    View.OnClickListener alertCardListener = v -> {
        v.setOnClickListener(null);
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setSelectedTab(R.id.navigation_alerts);
    };

    View.OnClickListener profileCardListener = v -> {
        v.setOnClickListener(null);
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setSelectedTab(R.id.navigation_profile);
    };

    View.OnClickListener syncCardListener = v -> {
        v.setOnClickListener(null);
        showLoadingDialog();
        NetworkManager.getInstance().fetchAccount();
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initializeViews(view);
    }

    @Override
    public void onResume() {
        initializeViews();

        //Check the NetworkManager to see if a sync is needed
        if (NetworkManager.getInstance().isSyncRequired()){
            View sync = getActivity().findViewById(R.id.card_sync);
            sync.setOnClickListener(syncCardListener);
            showLoadingDialog();
            NetworkManager.getInstance().fetchAccount();
        }
        super.onResume();
    }

    public void initializeViews(){
        initializeViews(getActivity().findViewById(R.id.layout_home_root));
    }

    private void initializeViews(View view) {
        View requests = view.findViewById(R.id.card_requests);
        requests.setOnClickListener(requestCardListener);

        View alerts = view.findViewById(R.id.card_alerts);
        alerts.setOnClickListener(alertCardListener);

        View profile = view.findViewById(R.id.card_profile);
        profile.setOnClickListener(profileCardListener);

        View sync = view.findViewById(R.id.card_sync);
        sync.setOnClickListener(syncCardListener);
    }

    private void showLoadingDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setTitle("Syncing Your Data...");
        builder.setView(inflater.inflate(R.layout.view_loading, null));
        builder.setCancelable(false);
        mLoadingDialog = builder.create();
        mLoadingDialog.show();
    }

    public void dismissLoadingDialog(){
        if (mLoadingDialog != null) {
            mLoadingDialog.dismiss();
            mLoadingDialog = null;
        }
    }

    @Override
    public void onDataChanged() {
        initializeViews();
        dismissLoadingDialog();
    }
}
